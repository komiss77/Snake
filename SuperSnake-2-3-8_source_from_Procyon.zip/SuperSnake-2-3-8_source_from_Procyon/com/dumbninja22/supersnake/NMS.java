// 
// Decompiled by Procyon v0.5.30
// 

package com.dumbninja22.supersnake;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.entity.Entity;

public interface NMS
{
    String numToEc(final int p0);
    
    void pathfind(final Entity p0, final Entity p1, final Player p2, final Minigame p3);
    
    void changeDir(final Entity p0, final Player p1);
    
    Entity spawnX(final Location p0, final Integer p1, final Float p2);
    
    void registerEntities();
    
    void showTitle(final String p0, final Player p1);
}
