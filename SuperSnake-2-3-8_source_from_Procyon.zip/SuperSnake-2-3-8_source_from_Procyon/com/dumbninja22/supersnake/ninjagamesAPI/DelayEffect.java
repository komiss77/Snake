// 
// Decompiled by Procyon v0.5.30
// 

package com.dumbninja22.supersnake.ninjagamesAPI;

import org.bukkit.plugin.Plugin;
import com.dumbninja22.supersnake.Main;
import org.bukkit.entity.Player;

public class DelayEffect
{
    int secondsToWait;
    int task;
    Player p;
    String servername;
    
    public DelayEffect(final int secondsToWait, final Player p3, final String servername) {
        this.secondsToWait = 0;
        this.secondsToWait = secondsToWait;
        this.p = p3;
        this.servername = servername;
        this.startCount();
    }
    
    public void startCount() {
        this.task = ((Main)Main.getPlugin((Class)Main.class)).getServer().getScheduler().scheduleSyncRepeatingTask((Plugin)Main.getPlugin((Class)Main.class), (Runnable)new Runnable() {
            @Override
            public void run() {
                final DelayEffect this$0 = DelayEffect.this;
                --this$0.secondsToWait;
                if (DelayEffect.this.secondsToWait < 1) {
                    ((Main)Main.getPlugin((Class)Main.class)).getServer().getScheduler().cancelTask(DelayEffect.this.task);
                    DelayEffect.this.secondsToWait = 0;
                    MySQLManager.bungee.sendPlayerToServer(DelayEffect.this.p, DelayEffect.this.servername);
                }
            }
        }, 0L, 20L);
    }
}
