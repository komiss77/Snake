// 
// Decompiled by Procyon v0.5.30
// 

package com.dumbninja22.supersnake.ninjagamesAPI;

import org.bukkit.ChatColor;
import java.util.Collection;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import java.io.IOException;
import java.io.File;
import org.bukkit.configuration.file.FileConfiguration;
import java.util.Random;
import java.util.Iterator;
import org.bukkit.entity.Player;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;

public class Utils
{
    public static Location stringToLoc(final String s) {
        if (s == null || s.trim().equals("")) {
            return null;
        }
        final String[] split = s.split(":");
        if (split.length == 4) {
            return new Location(Bukkit.getServer().getWorld(split[0]), (double)Double.valueOf(Double.parseDouble(split[1])), (double)Double.valueOf(Double.parseDouble(split[2])), (double)Double.valueOf(Double.parseDouble(split[3])));
        }
        return null;
    }
    
    public static void echo(final String s) {
        Bukkit.getLogger().info(s);
    }
    
    public static Player getPlayerByUUID(final UUID uuid) {
        for (final Player player : Bukkit.getOnlinePlayers()) {
            if (player.getUniqueId().toString().equals(uuid.toString())) {
                return player;
            }
        }
        return null;
    }
    
    public static int randInt(final int n, final int n2) {
        return new Random().nextInt(n2 - n + 1) + n;
    }
    
    public static void saveCustomYml(final FileConfiguration fileConfiguration, final File file) {
        try {
            fileConfiguration.save(file);
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    public static String locToString(final Location location) {
        if (location == null) {
            return "";
        }
        return String.valueOf(location.getWorld().getName()) + ":" + location.getBlockX() + ":" + location.getBlockY() + ":" + location.getBlockZ();
    }
    
    public static String sqlLocationListToText(final List<Location> list) {
        final ArrayList<String> list2 = new ArrayList<String>();
        final StringBuilder sb = new StringBuilder();
        final Iterator<Location> iterator = list.iterator();
        while (iterator.hasNext()) {
            list2.add(locToString(iterator.next()));
        }
        final Iterator<Object> iterator2 = list2.iterator();
        while (iterator2.hasNext()) {
            sb.append(iterator2.next());
            if (list2.size() > 1) {
                sb.append("\\|");
            }
        }
        return sb.toString();
    }
    
    public static List<Location> sqlTextToLocationList(final String s) {
        ArrayList<String> list;
        if (s.contains("\\|")) {
            list = new ArrayList<String>(Arrays.asList(s.split("\\|")));
        }
        else {
            list = new ArrayList<String>();
            list.add(s);
        }
        final ArrayList<Location> list2 = new ArrayList<Location>();
        for (final String s2 : list) {
            if (!s2.contains("\\|")) {
                list2.add(stringToLoc(s2));
            }
        }
        return list2;
    }
    
    public static String tran(final String s) {
        return ChatColor.translateAlternateColorCodes("&".charAt(0), s);
    }
}
