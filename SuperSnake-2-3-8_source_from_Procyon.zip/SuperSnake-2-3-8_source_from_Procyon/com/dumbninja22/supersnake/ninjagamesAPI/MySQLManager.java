// 
// Decompiled by Procyon v0.5.30
// 

package com.dumbninja22.supersnake.ninjagamesAPI;

import java.sql.Statement;
import org.bukkit.entity.Player;
import org.bukkit.Location;
import java.util.Map;
import java.util.ArrayList;
import java.util.UUID;
import java.util.Iterator;
import java.util.List;
import java.util.Arrays;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import com.dumbninja22.supersnake.Main;
import java.sql.Connection;
import org.bukkit.configuration.file.FileConfiguration;
import java.io.File;
import org.bukkit.plugin.Plugin;

public class MySQLManager
{
    public static boolean sqlEnabled;
    public static String hostname;
    public static int port;
    public static String database;
    public static String username;
    public static String password;
    public static boolean playerjoined;
    public static String serverToSendPlayerAfterGame;
    public static String arenaToSendPlayerAfterJoining;
    static Plugin plugin;
    static File customYml;
    static FileConfiguration customConfig;
    static MySQL MySQL;
    static Connection c;
    public static Bungee bungee;
    
    static {
        MySQLManager.sqlEnabled = false;
        MySQLManager.playerjoined = false;
        MySQLManager.serverToSendPlayerAfterGame = "none";
        MySQLManager.arenaToSendPlayerAfterJoining = "none";
        MySQLManager.plugin = (Plugin)Main.getPlugin((Class)Main.class);
        MySQLManager.customYml = new File(MySQLManager.plugin.getDataFolder() + "/sqldata.yml");
        MySQLManager.customConfig = (FileConfiguration)YamlConfiguration.loadConfiguration(MySQLManager.customYml);
        MySQLManager.c = null;
    }
    
    public static boolean doesArenaExistInDatabase(final String s) {
        try {
            final PreparedStatement prepareStatement = MySQLManager.MySQL.openConnection().prepareStatement("SELECT * FROM `supersnakearenas` WHERE `id` = ?");
            prepareStatement.setString(1, s);
            final ResultSet executeQuery = prepareStatement.executeQuery();
            if (executeQuery.next()) {
                return executeQuery.getString(1) != null;
            }
        }
        catch (ClassNotFoundException | SQLException ex) {
            final Object o2;
            final Object o = o2;
            Bukkit.getLogger().info("Something went wrong when checking on an arena in a database. The arena does not exist on this server, but might on another.");
            ((Throwable)o).printStackTrace();
        }
        return false;
    }
    
    public static void deleteArenaFromSQL(final String s) {
        try {
            final PreparedStatement prepareStatement = MySQLManager.MySQL.openConnection().prepareStatement("DELETE FROM `supersnakearenas` WHERE `id` = ?");
            prepareStatement.setString(1, s);
            prepareStatement.executeUpdate();
        }
        catch (SQLException | ClassNotFoundException ex) {
            final Object o2;
            final Object o = o2;
            Utils.echo("Something went wrong when deleting an arena from the SQL database. Please check the connection info and creditentials and try again.");
            ((Throwable)o).printStackTrace();
        }
    }
    
    public static void deleteAllArenaSignsFromSQL(final String s) {
        try {
            final PreparedStatement prepareStatement = MySQLManager.MySQL.openConnection().prepareStatement("DELETE FROM `supersnakesigns` WHERE `arena` = ?");
            prepareStatement.setString(1, s);
            prepareStatement.executeUpdate();
        }
        catch (SQLException | ClassNotFoundException ex) {
            final Object o2;
            final Object o = o2;
            Utils.echo("Something went wrong when deleting all signs for a specific arena from the SQL database. Please check the connection info and creditentials and try again.");
            ((Throwable)o).printStackTrace();
        }
    }
    
    public static void updateArena(final Arena arena) {
        if (arena == null) {
            return;
        }
        if (arena.getId() == null) {
            return;
        }
        if (arena.getBoundsLow() == null) {
            return;
        }
        if (arena.getBoundsHigh() == null) {
            return;
        }
        if (arena.getMainLobby() == null) {
            return;
        }
        if (arena.getServerId() == null) {
            return;
        }
        if (arena.getSpawns() == null) {
            return;
        }
        final String id = arena.getId();
        final String sqlLocationListToText = Utils.sqlLocationListToText(arena.getSpawns());
        final String locToString = Utils.locToString(arena.getBoundsLow());
        final String locToString2 = Utils.locToString(arena.getBoundsHigh());
        final String locToString3 = Utils.locToString(arena.getMainLobby());
        final String locToString4 = Utils.locToString(arena.getArenaLobby());
        final String serverId = arena.getServerId();
        try {
            final Connection openConnection = MySQLManager.MySQL.openConnection();
            final PreparedStatement prepareStatement = openConnection.prepareStatement("DELETE FROM `supersnakearenas` WHERE `id` = ?");
            prepareStatement.setString(1, id);
            prepareStatement.executeUpdate();
            final PreparedStatement prepareStatement2 = openConnection.prepareStatement("INSERT INTO `supersnakearenas` VALUES (?,?,?,?,?,?,?)");
            prepareStatement2.setString(1, id);
            prepareStatement2.setString(2, locToString);
            prepareStatement2.setString(3, locToString2);
            prepareStatement2.setString(4, sqlLocationListToText);
            prepareStatement2.setString(5, locToString3);
            prepareStatement2.setString(6, locToString4);
            prepareStatement2.setString(7, serverId);
            prepareStatement2.executeUpdate();
        }
        catch (ClassNotFoundException | SQLException ex) {
            final Object o2;
            final Object o = o2;
            Bukkit.getLogger().info("Something went wrong when updating the arena database.");
            ((Throwable)o).printStackTrace();
        }
    }
    
    public static String isPlayerWaitingToJoin(final String s) {
        try {
            final PreparedStatement prepareStatement = MySQLManager.MySQL.openConnection().prepareStatement("SELECT * FROM `joinarenawaiting` WHERE `player` = ?");
            prepareStatement.setString(1, s);
            final ResultSet executeQuery = prepareStatement.executeQuery();
            String string = "no";
            while (executeQuery.next()) {
                if (executeQuery.getString(1).equals(s)) {
                    string = executeQuery.getString(3);
                }
            }
            if (string.equals("no")) {
                return "no";
            }
            return string;
        }
        catch (ClassNotFoundException | SQLException ex) {
            final Object o2;
            final Object o = o2;
            Bukkit.getLogger().info("Something went wrong when checking on an arena in a database. The arena does not exist on this server, but might on another.");
            ((Throwable)o).printStackTrace();
            return "no";
        }
    }
    
    public static int getArenaMaxPlayers(final String s) {
        try {
            final PreparedStatement prepareStatement = MySQLManager.MySQL.openConnection().prepareStatement("SELECT * FROM `supersnakearenas` WHERE `id` = ?");
            prepareStatement.setString(1, s);
            final ResultSet executeQuery = prepareStatement.executeQuery();
            while (executeQuery.next()) {
                final String string = executeQuery.getString(1);
                final String string2 = executeQuery.getString(4);
                if (string.equals(s)) {
                    final List<String> list = Arrays.asList(string2.split("\\|"));
                    int n = 0;
                    for (final String s2 : list) {
                        if (s2 != null && !s2.contains("|")) {
                            ++n;
                        }
                    }
                    return n;
                }
            }
        }
        catch (SQLException | ClassNotFoundException ex) {
            final Object o2;
            final Object o = o2;
            Bukkit.getLogger().info("Something went wrong when checking on an arena in a database. The arena does not exist on this server, but might on another.");
            ((Throwable)o).printStackTrace();
        }
        return 0;
    }
    
    public static void setPlayerWaitingToJoinArena(final String s, final String s2, final String s3) {
        try {
            final PreparedStatement prepareStatement = MySQLManager.MySQL.openConnection().prepareStatement("INSERT INTO `joinarenawaiting` (`player`, `server`, `arena`) VALUES (?, ?, ?);");
            prepareStatement.setString(1, s);
            prepareStatement.setString(2, s2);
            prepareStatement.setString(3, s3);
            prepareStatement.executeUpdate();
        }
        catch (ClassNotFoundException | SQLException ex) {
            final Object o2;
            final Object o = o2;
            Bukkit.getLogger().info("Something went wrong when checking on an arena in a database. The arena does not exist on this server, but might on another.");
            ((Throwable)o).printStackTrace();
        }
    }
    
    public static void unsetPlayerWaitingToJoinArena(final String s) {
        try {
            final PreparedStatement prepareStatement = MySQLManager.MySQL.openConnection().prepareStatement("DELETE FROM `" + MySQLManager.database + "`.`joinarenawaiting` WHERE `joinarenawaiting`.`player` = ?");
            prepareStatement.setString(1, s);
            prepareStatement.executeUpdate();
        }
        catch (ClassNotFoundException | SQLException ex) {
            final Object o2;
            final Object o = o2;
            Bukkit.getLogger().info("Something went wrong when checking on an arena in a database. The arena does not exist on this server, but might on another.");
            ((Throwable)o).printStackTrace();
        }
    }
    
    public static String getArenaHomeServer(final String s) {
        try {
            final PreparedStatement prepareStatement = MySQLManager.MySQL.openConnection().prepareStatement("SELECT * FROM `supersnakearenas` WHERE `id` = ?");
            prepareStatement.setString(1, s);
            final ResultSet executeQuery = prepareStatement.executeQuery();
            if (executeQuery.next()) {
                if (executeQuery.getString(7) != null) {
                    return executeQuery.getString(7);
                }
                return "none";
            }
        }
        catch (ClassNotFoundException | SQLException ex) {
            final Object o2;
            final Object o = o2;
            Bukkit.getLogger().info("Something went wrong when checking on an arena in a database. The arena does not exist on this server, but might on another. 2");
            ((Throwable)o).printStackTrace();
        }
        return "none";
    }
    
    public static void sqlLoadPlayerShopItems() {
        try {
            final ResultSet executeQuery = MySQLManager.MySQL.openConnection().prepareStatement("SELECT * FROM `supersnakeshopdata`").executeQuery();
            while (executeQuery.next()) {
                final String string = executeQuery.getString(1);
                UUID uuid;
                if (string.matches("[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}")) {
                    uuid = UUID.fromString(string);
                }
                else {
                    uuid = Bukkit.getOfflinePlayer(executeQuery.getString(1)).getPlayer().getUniqueId();
                }
                if (uuid == null) {
                    continue;
                }
                ShopManager.colorChooser.put(uuid, Boolean.getBoolean(executeQuery.getString(2)));
                List<String> list = new ArrayList<String>();
                final List<String> list2 = ShopManager.owned.get(uuid);
                if (list2 != null && list2.size() > 0) {
                    list = list2;
                }
                if (executeQuery.getString(3).equals("true")) {
                    list.add("fastsnake");
                }
                if (executeQuery.getString(4).equals("true")) {
                    list.add("ferrarisnake");
                }
                ShopManager.owned.put(uuid, list);
            }
        }
        catch (ClassNotFoundException | SQLException ex) {
            final Object o2;
            final Object o = o2;
            Bukkit.getLogger().info("Something went wrong when checking on an arena in a database. The arena does not exist on this server, but might on another. 2");
            ((Throwable)o).printStackTrace();
        }
    }
    
    public static void sqlSavePlayerShopItems() {
        try {
            final Connection openConnection = MySQLManager.MySQL.openConnection();
            if (!MySQLManager.sqlEnabled) {
                return;
            }
            if (ShopManager.owned == null) {
                return;
            }
            for (final Map.Entry<UUID, List<String>> entry : ShopManager.owned.entrySet()) {
                final PreparedStatement prepareStatement = openConnection.prepareStatement("INSERT INTO `supersnakeshopdata`(`player`, `colorchooser`, `fastsnake`, `ferrarisnake`) VALUES (?,?,?,?)");
                prepareStatement.setString(1, entry.getKey().toString());
                String string = "false";
                if (ShopManager.colorChooser.containsKey(entry.getKey())) {
                    string = ShopManager.colorChooser.get(entry.getKey()).toString();
                }
                prepareStatement.setString(2, string);
                String s = "false";
                if (ShopManager.owned.containsKey(entry.getKey()) && ShopManager.owned.get(entry.getKey()).contains("fastsnake")) {
                    s = "true";
                }
                prepareStatement.setString(3, s);
                String s2 = "false";
                if (ShopManager.owned.containsKey(entry.getKey()) && ShopManager.owned.get(entry.getKey()).contains("ferrarisnake")) {
                    s2 = "true";
                }
                prepareStatement.setString(4, s2);
                prepareStatement.executeUpdate();
            }
        }
        catch (ClassNotFoundException | SQLException ex) {
            final Object o2;
            final Object o = o2;
            Bukkit.getLogger().info("Something went wrong when checking on an arena in a database. The arena does not exist on this server, but might on another. 3");
            ((Throwable)o).printStackTrace();
        }
    }
    
    public static void addToSQLArenaSignLocations(final Location location, final String s, final Player player, final String s2) {
        try {
            final Connection openConnection = MySQLManager.MySQL.openConnection();
            if (!MySQLManager.sqlEnabled) {
                return;
            }
            if (!doesArenaExistInDatabase(s)) {
                return;
            }
            final PreparedStatement prepareStatement = openConnection.prepareStatement("INSERT INTO `supersnakesigns`(`arena`, `location`, `serverfrom`, `serverto`) VALUES (?,?,?,?)");
            prepareStatement.setString(1, s);
            prepareStatement.setString(2, Utils.locToString(location));
            if (FileManager.bungee) {
                prepareStatement.setString(3, MySQLManager.bungee.getServerName(player));
                prepareStatement.setString(4, s2);
            }
            else {
                prepareStatement.setString(3, "none");
                prepareStatement.setString(4, "none");
            }
            prepareStatement.executeUpdate();
        }
        catch (ClassNotFoundException | SQLException ex) {
            final Object o2;
            final Object o = o2;
            Bukkit.getLogger().info("Something went wrong when checking on an arena in a database. The arena does not exist on this server, but might on another. 3");
            ((Throwable)o).printStackTrace();
        }
    }
    
    public static void deleteFromSQLArenaSignLocations(final Location location) {
        try {
            if (!MySQLManager.sqlEnabled) {
                return;
            }
            final PreparedStatement prepareStatement = MySQLManager.MySQL.openConnection().prepareStatement("DELETE FROM `supersnakesigns` WHERE location = ?");
            prepareStatement.setString(1, Utils.locToString(location));
            prepareStatement.executeUpdate();
        }
        catch (ClassNotFoundException | SQLException ex) {
            final Object o2;
            final Object o = o2;
            Bukkit.getLogger().info("Something went wrong when deleting a sign from the SQL database. Please re-check the connection data and try again. ");
            ((Throwable)o).printStackTrace();
        }
    }
    
    public static void loadFile() {
        MySQLManager.customConfig.addDefault("sqlEnabled", (Object)false);
        MySQLManager.customConfig.addDefault("hostname", (Object)"127.0.0.1");
        MySQLManager.customConfig.addDefault("port", (Object)3306);
        MySQLManager.customConfig.addDefault("database", (Object)"databasename");
        MySQLManager.customConfig.addDefault("username", (Object)"admin");
        MySQLManager.customConfig.addDefault("password", (Object)"thisIsTheBestPasswordEver");
        MySQLManager.customConfig.addDefault("serverToSendPlayerAfterGame", (Object)"none");
        MySQLManager.customConfig.addDefault("arenaToSendPlayerAfterJoining", (Object)"none");
        MySQLManager.customConfig.options().copyDefaults(true);
        Utils.saveCustomYml(MySQLManager.customConfig, MySQLManager.customYml);
        MySQLManager.sqlEnabled = MySQLManager.customConfig.getBoolean("sqlEnabled");
        MySQLManager.hostname = MySQLManager.customConfig.getString("hostname");
        MySQLManager.port = MySQLManager.customConfig.getInt("port");
        MySQLManager.database = MySQLManager.customConfig.getString("database");
        MySQLManager.username = MySQLManager.customConfig.getString("username");
        MySQLManager.password = MySQLManager.customConfig.getString("password");
        MySQLManager.serverToSendPlayerAfterGame = MySQLManager.customConfig.getString("serverToSendPlayerAfterGame");
        MySQLManager.arenaToSendPlayerAfterJoining = MySQLManager.customConfig.getString("arenaToSendPlayerAfterJoining");
        if (!MySQLManager.sqlEnabled) {
            FileManager.loadAll();
            SignManager.loadFile();
            Bukkit.getLogger().info("Reverting to flat-file...");
            return;
        }
        if (MySQLManager.password.contains("nopassword")) {
            MySQLManager.password = "";
            Bukkit.getLogger().info("No password...");
        }
        FileManager.loadBasic();
        MySQLManager.MySQL = new MySQL(MySQLManager.plugin, MySQLManager.hostname, MySQLManager.port, MySQLManager.database, MySQLManager.username, MySQLManager.password);
        MySQLManager.c = null;
        if (FileManager.bungee) {
            (MySQLManager.bungee = new Bungee()).initBungee();
        }
        try {
            MySQLManager.c = MySQLManager.MySQL.openConnection();
            final Statement statement = MySQLManager.c.createStatement();
            statement.executeUpdate("CREATE TABLE IF NOT EXISTS `supersnakearenas` (`id` varchar(255) NOT NULL,`boundslow` text NOT NULL,`boundshigh` text NOT NULL,`spawns` text NOT NULL,`mainlobby` text NOT NULL,`arenalobby` text NOT NULL,`server` varchar(255) NOT NULL, UNIQUE KEY `id` (`id`)) ENGINE=InnoDB DEFAULT CHARSET=latin1;");
            statement.executeUpdate("CREATE TABLE IF NOT EXISTS `supersnakesigns` (`arena` varchar(255) NOT NULL,`location` varchar(255) NOT NULL,`serverfrom` varchar(255) NOT NULL,`serverto` varchar(255) NOT NULL, UNIQUE KEY `location` (`location`)) ENGINE=InnoDB DEFAULT CHARSET=latin1;");
            statement.executeUpdate("CREATE TABLE IF NOT EXISTS `joinarenawaiting` (`player` varchar(255) NOT NULL,`server` varchar(255) NOT NULL,`arena` varchar(255) NOT NULL,UNIQUE KEY `player` (`player`)) ENGINE=InnoDB DEFAULT CHARSET=latin1;");
            statement.executeUpdate("CREATE TABLE IF NOT EXISTS `supersnakeshopdata` (`player` varchar(255) NOT NULL,`colorchooser` varchar(5) NOT NULL,`fastsnake` varchar(5) NOT NULL,`ferrarisnake` varchar(5) NOT NULL,UNIQUE KEY `player` (`player`)) ENGINE=InnoDB DEFAULT CHARSET=latin1;");
            final ResultSet executeQuery = statement.executeQuery("SELECT * FROM supersnakearenas;");
            try {
                while (executeQuery.next()) {
                    if (FileManager.bungee) {
                        final Arena massCreateArena = ArenaManager.getManager().massCreateArena(Utils.sqlTextToLocationList(executeQuery.getString(4)), executeQuery.getString(1), Utils.stringToLoc(executeQuery.getString(6)), Utils.stringToLoc(executeQuery.getString(5)), Utils.stringToLoc(executeQuery.getString(2)), Utils.stringToLoc(executeQuery.getString(3)), (Plugin)Main.getPlugin((Class)Main.class), executeQuery.getString(7));
                        if (FileManager.minPlayers.containsKey(massCreateArena.getId())) {
                            massCreateArena.setMinPlayers(FileManager.minPlayers.get(massCreateArena.getId()));
                        }
                        else {
                            massCreateArena.setMinPlayers(2);
                        }
                    }
                }
            }
            catch (NullPointerException ex) {
                ex.printStackTrace();
            }
            final ResultSet executeQuery2 = MySQLManager.c.createStatement().executeQuery("SELECT * FROM supersnakesigns;");
            while (executeQuery2.next()) {
                if (executeQuery2.isAfterLast()) {
                    break;
                }
                final String string = executeQuery2.getString(1);
                final String string2 = executeQuery2.getString(2);
                final String string3 = executeQuery2.getString(3);
                final String string4 = executeQuery2.getString(4);
                if (SignManager.signLocs.containsKey(string)) {
                    final List<Location> list = SignManager.signLocs.get(string);
                    list.add(Utils.stringToLoc(string2));
                    SignManager.signLocs.put(string, list);
                }
                else {
                    final ArrayList<Location> list2 = new ArrayList<Location>();
                    list2.add(Utils.stringToLoc(string2));
                    SignManager.signLocs.put(string, list2);
                }
                SignManager.serverfrom.put(Utils.stringToLoc(string2), string3);
                SignManager.serverto.put(Utils.stringToLoc(string2), string4);
            }
        }
        catch (ClassNotFoundException | SQLException ex2) {
            final Throwable t;
            t.printStackTrace();
            FileManager.loadAll();
            SignManager.loadFile();
            Bukkit.getLogger().info("Reverting to flat-file due to error");
        }
    }
    
    public static void saveAll() {
        try {
            saveSqlSigns();
            final Connection openConnection = new MySQL(MySQLManager.plugin, MySQLManager.hostname, MySQLManager.port, MySQLManager.database, MySQLManager.username, MySQLManager.password).openConnection();
            boolean b = false;
            for (final Arena arena : ArenaManager.getManager().getAllArenas()) {
                final Statement statement = openConnection.createStatement();
                final ResultSet executeQuery = statement.executeQuery("SELECT * FROM supersnakearenas;");
                while (executeQuery.next()) {
                    final Statement statement2 = openConnection.createStatement();
                    if (executeQuery.getString(1).equalsIgnoreCase(arena.getId())) {
                        statement2.executeUpdate("UPDATE `" + MySQLManager.database + "`.`supersnakearenas` SET `boundslow` = '" + Utils.locToString(arena.getBoundsLow()) + "', `boundshigh` = '" + Utils.locToString(arena.getBoundsHigh()) + "', `spawns` = '" + Utils.sqlLocationListToText(arena.getSpawns()) + "', `mainlobby` = '" + Utils.locToString(arena.getMainLobby()) + "', `arenalobby` = '" + Utils.locToString(arena.getArenaLobby()) + "', `server` = '" + arena.getServerId() + "' WHERE `supersnakearenas`.`id` = '" + arena.getId() + "';");
                        b = true;
                    }
                }
                if (!b) {
                    statement.executeUpdate("INSERT INTO `" + MySQLManager.database + "`.`supersnakearenas` (`id`, `boundslow`, `boundshigh`, `spawns`, `mainlobby`, `arenalobby`, `server`) VALUES ('" + arena.getId() + "', '" + Utils.locToString(arena.getBoundsLow()) + "', '" + Utils.locToString(arena.getBoundsHigh()) + "', '" + Utils.sqlLocationListToText(arena.getSpawns()) + "', '" + Utils.locToString(arena.getMainLobby()) + "', '" + Utils.locToString(arena.getArenaLobby()) + "', '" + arena.getServerId() + "');");
                }
            }
        }
        catch (SQLException | ClassNotFoundException ex) {
            final Object o2;
            final Object o = o2;
            Bukkit.getLogger().info("Oh noes. Not this. SQL Exception!! Nooooooooooo");
            ((Throwable)o).printStackTrace();
        }
    }
    
    public static void saveSqlSigns() {
        try {
            final Connection openConnection = new MySQL(MySQLManager.plugin, MySQLManager.hostname, MySQLManager.port, MySQLManager.database, MySQLManager.username, MySQLManager.password).openConnection();
            final Iterator<Arena> iterator = ArenaManager.getManager().getAllArenas().iterator();
        Label_0417:
            while (true) {
                break Label_0417;
                Arena arena = null;
                do {
                    try {
                        for (final Location location : SignManager.signLocs.get(arena.getId())) {
                            final Statement statement = openConnection.createStatement();
                            if (FileManager.bungee) {
                                statement.executeUpdate("INSERT INTO `" + MySQLManager.database + "`.`supersnakesigns` (`arena`, `location`, `serverfrom`, `serverto`) VALUES ('" + arena.getId() + "', '" + Utils.locToString(location) + "', '" + SignManager.serverfrom.get(location) + "'" + ", '" + SignManager.serverto.get(location) + "');");
                            }
                            else {
                                statement.executeUpdate("INSERT INTO `" + MySQLManager.database + "`.`supersnakesigns` (`arena`, `location`, `serverfrom`, `serverto`) VALUES ('" + arena.getId() + "', '" + Utils.locToString(location) + "', '" + "none" + "'" + ", '" + "none" + "');");
                            }
                        }
                        if (!iterator.hasNext()) {
                            return;
                        }
                    }
                    catch (ClassNotFoundException ex) {
                        Bukkit.getLogger().info("Oh noes. Not this. SQL Exception (signs)!! Nooooooooooo");
                    }
                    arena = iterator.next();
                    if (arena.getServerId().equals(MySQLManager.bungee.servername)) {
                        continue Label_0417;
                    }
                    openConnection.createStatement().executeUpdate("DELETE FROM `supersnakesigns` WHERE `arena`= '" + arena.getId() + "' AND `serverfrom` = '" + MySQLManager.bungee.servername + "`;");
                } while (SignManager.signLocs != null && SignManager.signLocs.size() >= 1 && SignManager.signLocs.get(arena.getId()) != null);
                break;
            }
        }
        catch (SQLException ex2) {}
        catch (ClassNotFoundException ex3) {}
        catch (NullPointerException ex4) {}
    }
}
