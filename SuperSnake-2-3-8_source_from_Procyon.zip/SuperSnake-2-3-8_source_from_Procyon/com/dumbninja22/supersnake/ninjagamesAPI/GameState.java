// 
// Decompiled by Procyon v0.5.30
// 

package com.dumbninja22.supersnake.ninjagamesAPI;

public enum GameState
{
    WAITING("WAITING", 0), 
    STARTING("STARTING", 1), 
    INGAME("INGAME", 2), 
    STARTED("STARTED", 3);
    
    private GameState(final String s, final int n) {
    }
}
