// 
// Decompiled by Procyon v0.5.30
// 

package com.dumbninja22.supersnake.ninjagamesAPI;

import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Score;
import org.bukkit.scoreboard.DisplaySlot;
import com.google.common.base.Splitter;
import java.util.AbstractMap;
import java.util.Iterator;
import java.util.HashSet;
import com.google.common.collect.Lists;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.ChatColor;
import org.bukkit.Bukkit;
import java.util.HashMap;
import java.util.Set;
import org.bukkit.scoreboard.Team;
import java.util.List;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.OfflinePlayer;
import java.util.Map;

public class SimpleScoreboard
{
    private static Map<String, OfflinePlayer> cache;
    private Scoreboard scoreboard;
    private String title;
    private Map<String, Integer> scores;
    private Objective obj;
    private List<Team> teams;
    private List<Integer> removed;
    private Set<String> updated;
    
    static {
        SimpleScoreboard.cache = new HashMap<String, OfflinePlayer>();
    }
    
    public SimpleScoreboard(final String s) {
        this.scoreboard = Bukkit.getScoreboardManager().getNewScoreboard();
        this.title = ChatColor.translateAlternateColorCodes('&', s);
        this.scores = new ConcurrentHashMap<String, Integer>();
        this.teams = new ArrayList<Team>();
        this.removed = (List<Integer>)Lists.newArrayList();
        this.updated = new HashSet<String>();
    }
    
    public void add(String translateAlternateColorCodes, final Integer n) {
        translateAlternateColorCodes = ChatColor.translateAlternateColorCodes('&', translateAlternateColorCodes);
        if (this.remove(n, translateAlternateColorCodes, false) || !this.scores.containsValue(n)) {
            this.updated.add(translateAlternateColorCodes);
        }
        this.scores.put(translateAlternateColorCodes, n);
    }
    
    public boolean remove(final Integer n, final String s) {
        return this.remove(n, s, true);
    }
    
    public boolean remove(final Integer n, final String s, final boolean b) {
        final String value = this.get(n, s);
        if (value == null) {
            return false;
        }
        this.scores.remove(value);
        if (b) {
            this.removed.add(n);
        }
        return true;
    }
    
    public String get(final int n, final String s) {
        String s2 = null;
        for (final Map.Entry<String, Integer> entry : this.scores.entrySet()) {
            if (entry.getValue().equals(n) && !entry.getKey().equals(s)) {
                s2 = entry.getKey();
            }
        }
        return s2;
    }
    
    private Map.Entry<Team, OfflinePlayer> createTeam(final String s, final int n) {
        final ChatColor chatColor = ChatColor.values()[n];
        if (!SimpleScoreboard.cache.containsKey(chatColor.toString())) {
            SimpleScoreboard.cache.put(chatColor.toString(), Bukkit.getOfflinePlayer(chatColor.toString()));
        }
        final OfflinePlayer offlinePlayer = SimpleScoreboard.cache.get(chatColor.toString());
        Team team;
        try {
            team = this.scoreboard.registerNewTeam("text-" + (this.teams.size() + 1));
        }
        catch (IllegalArgumentException ex) {
            team = this.scoreboard.getTeam("text-" + this.teams.size());
        }
        this.applyText(team, s, offlinePlayer);
        this.teams.add(team);
        return new AbstractMap.SimpleEntry<Team, OfflinePlayer>(team, offlinePlayer);
    }
    
    private void applyText(final Team team, final String s, final OfflinePlayer offlinePlayer) {
        final Iterator<String> iterator = Splitter.fixedLength(16).split((CharSequence)s).iterator();
        final String prefix = iterator.next();
        team.setPrefix(prefix);
        if (!team.hasPlayer(offlinePlayer)) {
            team.addPlayer(offlinePlayer);
        }
        if (s.length() > 16) {
            String s2 = ChatColor.getLastColors(prefix);
            String s3 = iterator.next();
            if (prefix.endsWith("§")) {
                team.setPrefix(prefix.substring(0, prefix.length() - 1));
                s2 = ChatColor.getByChar(s3.charAt(0)).toString();
                s3 = s3.substring(1);
            }
            if (s2 == null) {
                s2 = "";
            }
            if (s3.length() > 16) {
                s3 = s3.substring(0, 13 - s2.length());
            }
            team.setSuffix((s2.equals("") ? ChatColor.RESET : s2) + s3);
        }
    }
    
    public void update() {
        if (this.updated.isEmpty()) {
            return;
        }
        if (this.obj == null) {
            (this.obj = this.scoreboard.registerNewObjective((this.title.length() > 16) ? this.title.substring(0, 15) : this.title, "dummy")).setDisplayName(this.title);
            this.obj.setDisplaySlot(DisplaySlot.SIDEBAR);
        }
        for (final int intValue : this.removed) {
            for (final OfflinePlayer offlinePlayer : this.scoreboard.getPlayers()) {
                final Score score = this.obj.getScore(offlinePlayer);
                if (score == null) {
                    continue;
                }
                if (score.getScore() != intValue) {
                    continue;
                }
                this.scoreboard.resetScores(offlinePlayer);
            }
        }
        this.removed.clear();
        int size = this.scores.size();
        for (final Map.Entry<String, Integer> entry : this.scores.entrySet()) {
            final Team team = this.scoreboard.getTeam(ChatColor.values()[entry.getValue()].toString());
            if (!this.updated.contains(entry.getKey())) {
                continue;
            }
            if (team != null) {
                final String string = ChatColor.values()[entry.getValue()].toString();
                if (!SimpleScoreboard.cache.containsKey(string)) {
                    SimpleScoreboard.cache.put(string, Bukkit.getOfflinePlayer(string));
                }
                final AbstractMap.SimpleEntry simpleEntry = new AbstractMap.SimpleEntry<Team, OfflinePlayer>(team, (V)SimpleScoreboard.cache.get(string));
                this.applyText(simpleEntry.getKey(), entry.getKey(), simpleEntry.getValue());
                --size;
            }
            else {
                this.obj.getScore((OfflinePlayer)this.createTeam(entry.getKey(), entry.getValue()).getValue()).setScore((int)Integer.valueOf((entry.getValue() != null) ? entry.getValue() : size));
                --size;
            }
        }
        this.updated.clear();
    }
    
    public void setTitle(final String displayName) {
        this.title = ChatColor.translateAlternateColorCodes('&', displayName);
        if (this.obj != null) {
            this.obj.setDisplayName(displayName);
        }
    }
    
    public void reset() {
        final Iterator<Team> iterator = this.teams.iterator();
        while (iterator.hasNext()) {
            iterator.next().unregister();
        }
        this.teams.clear();
        this.scores.clear();
    }
    
    public Scoreboard getScoreboard() {
        return this.scoreboard;
    }
    
    public void send(final Player... array) {
        for (int length = array.length, i = 0; i < length; ++i) {
            array[i].setScoreboard(this.scoreboard);
        }
    }
}
