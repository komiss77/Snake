// 
// Decompiled by Procyon v0.5.30
// 

package com.dumbninja22.supersnake.ninjagamesAPI;

import java.io.IOException;
import java.io.OutputStream;
import java.io.DataOutputStream;
import java.io.ByteArrayOutputStream;
import org.bukkit.entity.Player;
import com.google.common.io.ByteStreams;
import org.bukkit.plugin.Plugin;
import com.dumbninja22.supersnake.Main;
import org.bukkit.Bukkit;
import com.google.common.io.ByteArrayDataOutput;
import com.google.common.io.ByteArrayDataInput;
import org.bukkit.plugin.messaging.PluginMessageListener;

public class Bungee implements PluginMessageListener
{
    ByteArrayDataInput inn;
    ByteArrayDataOutput out;
    String servername;
    
    public Bungee() {
        this.servername = "";
    }
    
    public void initBungee() {
        if (!FileManager.bungee || !MySQLManager.sqlEnabled) {
            return;
        }
        Bukkit.getServer().getMessenger().registerOutgoingPluginChannel((Plugin)Main.getPlugin((Class)Main.class), "BungeeCord");
        Bukkit.getServer().getMessenger().registerIncomingPluginChannel((Plugin)Main.getPlugin((Class)Main.class), "BungeeCord", (PluginMessageListener)this);
        this.out = ByteStreams.newDataOutput();
    }
    
    public String getServerName(final Player player) {
        final ByteArrayDataOutput dataOutput = ByteStreams.newDataOutput();
        dataOutput.writeUTF("GetServer");
        player.sendPluginMessage((Plugin)Main.getPlugin((Class)Main.class), "BungeeCord", dataOutput.toByteArray());
        return this.servername;
    }
    
    public void initGetServerName(final Player player) {
        final ByteArrayDataOutput dataOutput = ByteStreams.newDataOutput();
        dataOutput.writeUTF("GetServer");
        player.sendPluginMessage((Plugin)Main.getPlugin((Class)Main.class), "BungeeCord", dataOutput.toByteArray());
    }
    
    public void sendPlayerToServer(final Player player, final String s) {
        final ByteArrayDataOutput dataOutput = ByteStreams.newDataOutput();
        dataOutput.writeUTF("ConnectOther");
        dataOutput.writeUTF(player.getDisplayName());
        dataOutput.writeUTF(s);
        player.sendPluginMessage((Plugin)Main.getPlugin((Class)Main.class), "BungeeCord", dataOutput.toByteArray());
    }
    
    public void updateUniversalSigns(final Player player, final String s, final int n, final int n2) {
        final ByteArrayDataOutput dataOutput = ByteStreams.newDataOutput();
        dataOutput.writeUTF("Forward");
        dataOutput.writeUTF("ALL");
        dataOutput.writeUTF("supersnakeupdatesigns:" + s + ":" + n + ":" + n2);
        final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        final DataOutputStream dataOutputStream = new DataOutputStream(byteArrayOutputStream);
        try {
            dataOutputStream.writeUTF("supersnakeupdatesigns:" + s + ":" + n + ":" + n2);
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
        try {
            dataOutputStream.writeShort(123);
        }
        catch (IOException ex2) {
            ex2.printStackTrace();
        }
        dataOutput.writeShort(byteArrayOutputStream.toByteArray().length);
        dataOutput.write(byteArrayOutputStream.toByteArray());
        player.sendPluginMessage((Plugin)Main.getPlugin((Class)Main.class), "BungeeCord", dataOutput.toByteArray());
    }
    
    public void joinPlayerArena(final Player player, final String s, final String s2) {
        MySQLManager.setPlayerWaitingToJoinArena(player.getDisplayName(), s2, s);
        this.sendPlayerToServer(player, s2);
    }
    
    public void onPluginMessageReceived(final String s, final Player player, final byte[] array) {
        if (!s.equals("BungeeCord")) {
            return;
        }
        this.inn = ByteStreams.newDataInput(array);
        final String utf = this.inn.readUTF();
        if (!utf.contains("byugyg8")) {
            if (utf.contains("GetServer")) {
                this.servername = this.inn.readUTF();
            }
            else if (utf.contains("supersnakeupdatesigns")) {
                final String[] split = utf.split(":");
                final String s2 = split[1];
                if (SignManager.signLocs.containsKey(s2)) {
                    SignManager.updateSigns(s2, Integer.valueOf(split[2]), Integer.valueOf(split[3]));
                }
            }
        }
    }
}
