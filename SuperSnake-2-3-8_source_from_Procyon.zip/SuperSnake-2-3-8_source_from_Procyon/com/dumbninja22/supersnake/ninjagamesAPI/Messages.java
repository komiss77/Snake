// 
// Decompiled by Procyon v0.5.30
// 

package com.dumbninja22.supersnake.ninjagamesAPI;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Iterator;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.YamlConfiguration;
import com.dumbninja22.supersnake.Main;
import org.bukkit.configuration.file.FileConfiguration;
import java.io.File;
import org.bukkit.plugin.Plugin;

public class Messages
{
    static Plugin plugin;
    static File customYml;
    static FileConfiguration customConfig;
    public static String gameStartingIn;
    public static String arenaStartingMessage;
    public static String titleMessageLose;
    public static String titleMessageWin;
    public static String playerJoinArena;
    public static String errorJoinMoreThenOneArena;
    public static String leaveArenaGuiItem;
    public static String guiShopItemName;
    public static String errorInsufficiantFunds;
    public static String fastSnakeKitName;
    public static String ferrariSnakeKitName;
    public static String itemAlreadyOwned;
    public static String colorChooserName;
    public static String purchaseColorChooser;
    public static String selectedKitMessage;
    public static String selectedColorMessage;
    public static String purchasedAndSelectedMessage;
    public static String playerLeaveGameMessage;
    public static String joinInvalidArenaMessage;
    public static String joinArenaBadArguments;
    public static String playerLeaveArenaMessage;
    public static String playerLeaveNotInArena;
    public static String goMessage;
    public static String gameStartingPleaseWaitMessage;
    public static String playerLeaveBoundsMessage;
    public static String snakeHitMessage;
    public static String gameAlreadyStarted;
    public static String scoreboardTitle;
    public static String firstLineOfSign;
    public static String commandBlockerMsg;
    public static String creditForParticipation;
    public static String creditForWin;
    public static String creditForHitSomeoneOut;
    
    static {
        Messages.plugin = (Plugin)Main.getPlugin((Class)Main.class);
        Messages.customYml = new File(Messages.plugin.getDataFolder() + "/messages.yml");
        Messages.customConfig = (FileConfiguration)YamlConfiguration.loadConfiguration(Messages.customYml);
    }
    
    public static void loadAll() {
        Messages.customConfig.addDefault("gameStartingIn", (Object)"&6&lGame Starting In [X] Seconds!");
        Messages.customConfig.addDefault("arenaStartingMessage", (Object)"&3&lArena Starting In [X] Seconds!");
        Messages.customConfig.addDefault("titleMessageLose", (Object)"YOU LOSE!");
        Messages.customConfig.addDefault("titleMessageWin", (Object)"YOU WIN!");
        Messages.customConfig.addDefault("playerJoinArena", (Object)"You have joined an arena!");
        Messages.customConfig.addDefault("errorJoinMoreThenOneArena", (Object)"You cannot join more then one arena!");
        Messages.customConfig.addDefault("leaveArenaGuiItem", (Object)"Leave Arena");
        Messages.customConfig.addDefault("guiShopItemName", (Object)"&5Shop");
        Messages.customConfig.addDefault("errorInsufficiantFunds", (Object)"&cYou can't afford that!");
        Messages.customConfig.addDefault("fastSnakeKitName", (Object)"Fast Snake");
        Messages.customConfig.addDefault("ferrariSnakeKitName", (Object)"Ferrari Snake");
        Messages.customConfig.addDefault("itemAlreadyOwned", (Object)"&cYou already own that!");
        Messages.customConfig.addDefault("colorChooserName", (Object)"Color Chooser");
        Messages.customConfig.addDefault("purchaseColorChooser", (Object)"&aYou have purchased the color chooser!");
        Messages.customConfig.addDefault("selectedKitMessage", (Object)"&3You have selected kit [X]!");
        Messages.customConfig.addDefault("selectedColorMessage", (Object)"&3&lYou have selected [X] as your snake color!");
        Messages.customConfig.addDefault("purchasedAndSelectedMessage", (Object)"&3&lYou have purchased and selected kit [X]!");
        Messages.customConfig.addDefault("playerLeaveGameMessage", (Object)"&c[X] has left the game!");
        Messages.customConfig.addDefault("joinInvalidArenaMessage", (Object)"&cInvalid Arena!");
        Messages.customConfig.addDefault("joinArenaBadArguments", (Object)"&cInvalid Arguments! To join an arena you must do /snake join <arena name>");
        Messages.customConfig.addDefault("playerLeaveArenaMessage", (Object)"You have left the arena!");
        Messages.customConfig.addDefault("playerLeaveNotInArena", (Object)"&cYou are not in an arena!");
        Messages.customConfig.addDefault("goMessage", (Object)"&l&6Go!!");
        Messages.customConfig.addDefault("gameStartingPleaseWaitMessage", (Object)"&6Game Starting - Please Wait");
        Messages.customConfig.addDefault("playerLeaveBoundsMessage", (Object)"&cYou are not allowed to leave the arena!");
        Messages.customConfig.addDefault("snakeHitMessage", (Object)"&3[X] was hit by [Y]'s snake. [Z] Players remain.");
        Messages.customConfig.addDefault("gameAlreadyStarted", (Object)"&cThis arena is already in-game. Please try another.");
        Messages.customConfig.addDefault("scoreboardTitle", (Object)"&6Super Snake");
        Messages.customConfig.addDefault("firstLineOfSign", (Object)"&6[Super Snake]");
        Messages.customConfig.addDefault("commandBlockerMsg", (Object)"&cYou were kicked from the arena!");
        Messages.customConfig.addDefault("creditForParticipation", (Object)"&6+[X] Gems for participation!");
        Messages.customConfig.addDefault("creditForWin", (Object)"&6+[X] Gems for winning!");
        Messages.customConfig.addDefault("creditForHitSomeoneOut", (Object)"&6+[X] Gems for [Y] kills!");
        Messages.customConfig.options().copyDefaults(true);
        saveCustomYml(Messages.customConfig, Messages.customYml);
        try {
            for (final String s : Messages.customConfig.getKeys(false)) {
                final Field field = Messages.class.getField(s);
                field.setAccessible(true);
                field.set(null, Messages.customConfig.getString(s));
            }
        }
        catch (Exception ex) {
            ((Main)Main.getPlugin((Class)Main.class)).getLogger().severe(ChatColor.RED + "Super Snake is having some issues loading the messages.yml. Please be sure you did not add any custom values or break anything. If this message persists, please delete messages.yml and try again.");
        }
    }
    
    private static void saveCustomYml(final FileConfiguration fileConfiguration, final File file) {
        try {
            fileConfiguration.save(file);
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
