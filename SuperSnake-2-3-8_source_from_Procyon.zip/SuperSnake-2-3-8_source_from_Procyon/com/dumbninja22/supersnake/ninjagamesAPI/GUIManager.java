// 
// Decompiled by Procyon v0.5.30
// 

package com.dumbninja22.supersnake.ninjagamesAPI;

import org.bukkit.event.EventPriority;
import org.bukkit.OfflinePlayer;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.EventHandler;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.entity.Player;
import java.util.List;
import java.util.ArrayList;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.ChatColor;
import org.bukkit.event.block.Action;
import org.bukkit.Material;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.plugin.Plugin;
import com.dumbninja22.supersnake.Main;
import org.bukkit.Bukkit;
import org.bukkit.event.Listener;

public class GUIManager implements Listener
{
    public static void registerManager() {
        Bukkit.getServer().getPluginManager().registerEvents((Listener)new GUIManager(), (Plugin)Main.getPlugin((Class)Main.class));
    }
    
    @EventHandler
    public static void onRightClick(final PlayerInteractEvent playerInteractEvent) {
        final Player player = playerInteractEvent.getPlayer();
        if (player.getItemInHand() == null || player.getItemInHand().getType() == Material.AIR) {
            return;
        }
        if (playerInteractEvent.getAction() == Action.RIGHT_CLICK_AIR || playerInteractEvent.getAction() == Action.LEFT_CLICK_AIR || playerInteractEvent.getAction() == Action.RIGHT_CLICK_BLOCK) {
            if (player.getItemInHand() != null && player.getItemInHand().getType() == Material.STAINED_GLASS_PANE && ArenaManager.getManager().searchForPlayer(playerInteractEvent.getPlayer()) && player.getItemInHand().hasItemMeta() && player.getItemInHand().getItemMeta().hasDisplayName() && player.getItemInHand().getItemMeta().getDisplayName().equals(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.leaveArenaGuiItem))) {
                playerInteractEvent.setCancelled(true);
                ArenaManager.getManager().removePlayer(playerInteractEvent.getPlayer(), false);
            }
            if (player.getItemInHand() != null && player.getItemInHand().getType() == Material.NAME_TAG && ArenaManager.getManager().searchForPlayer(playerInteractEvent.getPlayer()) && player.getItemInHand().hasItemMeta() && player.getItemInHand().getItemMeta().hasDisplayName() && player.getItemInHand().getItemMeta().getDisplayName().contains(Messages.colorChooserName)) {
                final ItemStack itemStack = new ItemStack(Material.WOOL, 1, (short)0);
                final ItemStack itemStack2 = new ItemStack(Material.WOOL, 1, (short)1);
                final ItemStack itemStack3 = new ItemStack(Material.WOOL, 1, (short)2);
                final ItemStack itemStack4 = new ItemStack(Material.WOOL, 1, (short)3);
                final ItemStack itemStack5 = new ItemStack(Material.WOOL, 1, (short)4);
                final ItemStack itemStack6 = new ItemStack(Material.WOOL, 1, (short)5);
                final ItemStack itemStack7 = new ItemStack(Material.WOOL, 1, (short)6);
                final ItemStack itemStack8 = new ItemStack(Material.WOOL, 1, (short)7);
                final ItemStack itemStack9 = new ItemStack(Material.WOOL, 1, (short)8);
                final ItemStack itemStack10 = new ItemStack(Material.WOOL, 1, (short)9);
                final ItemStack itemStack11 = new ItemStack(Material.WOOL, 1, (short)10);
                final ItemStack itemStack12 = new ItemStack(Material.WOOL, 1, (short)11);
                final ItemStack itemStack13 = new ItemStack(Material.WOOL, 1, (short)12);
                final ItemStack itemStack14 = new ItemStack(Material.WOOL, 1, (short)13);
                final ItemStack itemStack15 = new ItemStack(Material.WOOL, 1, (short)14);
                final ItemStack itemStack16 = new ItemStack(Material.WOOL, 1, (short)15);
                final ItemMeta itemMeta = itemStack.getItemMeta();
                final ItemMeta itemMeta2 = itemStack2.getItemMeta();
                final ItemMeta itemMeta3 = itemStack3.getItemMeta();
                final ItemMeta itemMeta4 = itemStack4.getItemMeta();
                final ItemMeta itemMeta5 = itemStack5.getItemMeta();
                final ItemMeta itemMeta6 = itemStack6.getItemMeta();
                final ItemMeta itemMeta7 = itemStack7.getItemMeta();
                final ItemMeta itemMeta8 = itemStack8.getItemMeta();
                final ItemMeta itemMeta9 = itemStack9.getItemMeta();
                final ItemMeta itemMeta10 = itemStack10.getItemMeta();
                final ItemMeta itemMeta11 = itemStack11.getItemMeta();
                final ItemMeta itemMeta12 = itemStack12.getItemMeta();
                final ItemMeta itemMeta13 = itemStack13.getItemMeta();
                final ItemMeta itemMeta14 = itemStack14.getItemMeta();
                final ItemMeta itemMeta15 = itemStack15.getItemMeta();
                final ItemMeta itemMeta16 = itemStack16.getItemMeta();
                itemMeta.setDisplayName(ChatColor.WHITE + "White Snake");
                itemMeta2.setDisplayName(ChatColor.GOLD + "Orange Snake");
                itemMeta3.setDisplayName(ChatColor.DARK_PURPLE + "Magenta Snake");
                itemMeta4.setDisplayName(ChatColor.BLUE + "Light Blue Snake");
                itemMeta5.setDisplayName(ChatColor.YELLOW + "Yellow Snake");
                itemMeta6.setDisplayName(ChatColor.GREEN + "Lime Snake");
                itemMeta7.setDisplayName(ChatColor.LIGHT_PURPLE + "Pink Snake");
                itemMeta8.setDisplayName(ChatColor.DARK_GRAY + "Gray Snake");
                itemMeta9.setDisplayName(ChatColor.GRAY + "Light Gray Snake");
                itemMeta10.setDisplayName(ChatColor.AQUA + "Cyan Snake");
                itemMeta11.setDisplayName(ChatColor.DARK_PURPLE + "Purple Snake");
                itemMeta12.setDisplayName(ChatColor.DARK_BLUE + "Blue Snake");
                itemMeta13.setDisplayName(ChatColor.BLACK + "Brown Snake");
                itemMeta14.setDisplayName(ChatColor.DARK_GREEN + "Green Snake");
                itemMeta15.setDisplayName(ChatColor.RED + "Red Snake");
                itemMeta16.setDisplayName(ChatColor.BLACK + "Black Snake");
                itemStack.setItemMeta(itemMeta);
                itemStack2.setItemMeta(itemMeta2);
                itemStack3.setItemMeta(itemMeta3);
                itemStack4.setItemMeta(itemMeta4);
                itemStack5.setItemMeta(itemMeta5);
                itemStack6.setItemMeta(itemMeta6);
                itemStack7.setItemMeta(itemMeta7);
                itemStack8.setItemMeta(itemMeta8);
                itemStack9.setItemMeta(itemMeta9);
                itemStack10.setItemMeta(itemMeta10);
                itemStack11.setItemMeta(itemMeta11);
                itemStack12.setItemMeta(itemMeta12);
                itemStack13.setItemMeta(itemMeta13);
                itemStack14.setItemMeta(itemMeta14);
                itemStack15.setItemMeta(itemMeta15);
                itemStack16.setItemMeta(itemMeta16);
                final Inventory inventory = Bukkit.createInventory((InventoryHolder)null, 18, Messages.colorChooserName);
                inventory.setItem(0, itemStack);
                inventory.setItem(1, itemStack2);
                inventory.setItem(2, itemStack3);
                inventory.setItem(3, itemStack4);
                inventory.setItem(4, itemStack5);
                inventory.setItem(5, itemStack6);
                inventory.setItem(6, itemStack7);
                inventory.setItem(7, itemStack8);
                inventory.setItem(8, itemStack9);
                inventory.setItem(9, new ItemStack(Material.AIR));
                inventory.setItem(10, itemStack10);
                inventory.setItem(11, itemStack11);
                inventory.setItem(12, itemStack12);
                inventory.setItem(13, itemStack13);
                inventory.setItem(14, itemStack14);
                inventory.setItem(15, itemStack15);
                inventory.setItem(16, itemStack16);
                inventory.setItem(17, new ItemStack(Material.AIR));
                player.openInventory(inventory);
            }
            if (player.getItemInHand() != null && player.getItemInHand().getType() == Material.DIAMOND && ArenaManager.getManager().searchForPlayer(playerInteractEvent.getPlayer()) && player.getItemInHand().hasItemMeta() && player.getItemInHand().getItemMeta().hasDisplayName() && player.getItemInHand().getItemMeta().getDisplayName().equalsIgnoreCase(ChatColor.DARK_PURPLE + "Shop")) {
                if (EconomyManager.economy == null) {
                    return;
                }
                final ItemStack itemStack17 = new ItemStack(Material.NAME_TAG);
                final ItemStack itemStack18 = new ItemStack(Material.FEATHER, FileManager.fastKitBoosts);
                final ItemStack itemStack19 = new ItemStack(Material.FEATHER, FileManager.ferrariKitBoosts);
                final ItemMeta itemMeta17 = itemStack17.getItemMeta();
                final ItemMeta itemMeta18 = itemStack18.getItemMeta();
                final ItemMeta itemMeta19 = itemStack19.getItemMeta();
                if (ShopManager.findPlayerInColorChooser(player.getUniqueId())) {
                    itemMeta17.setDisplayName(ChatColor.GREEN + Messages.colorChooserName);
                    final ArrayList<String> lore = new ArrayList<String>();
                    lore.add(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.itemAlreadyOwned));
                    itemMeta17.setLore((List)lore);
                }
                else {
                    final ArrayList<String> lore2 = new ArrayList<String>();
                    lore2.add(new StringBuilder().append(ChatColor.GREEN).append(FileManager.priceColorChooser).append(" ").append(EconomyManager.economy.currencyNamePlural()).toString());
                    itemMeta17.setLore((List)lore2);
                    itemMeta17.setDisplayName(ChatColor.RED + Messages.colorChooserName);
                }
                if (ShopManager.findPlayerInOwned(player.getUniqueId(), "fastsnake")) {
                    itemMeta18.setDisplayName(ChatColor.GREEN + Messages.fastSnakeKitName);
                    final ArrayList<String> lore3 = new ArrayList<String>();
                    lore3.add(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.itemAlreadyOwned));
                    itemMeta18.setLore((List)lore3);
                }
                else {
                    final ArrayList<String> lore4 = new ArrayList<String>();
                    lore4.add(new StringBuilder().append(ChatColor.GREEN).append(FileManager.fastSnakePrice).append(" ").append(EconomyManager.economy.currencyNamePlural()).toString());
                    itemMeta18.setLore((List)lore4);
                    itemMeta18.setDisplayName(ChatColor.RED + Messages.fastSnakeKitName);
                }
                if (ShopManager.findPlayerInOwned(player.getUniqueId(), "ferrarisnake")) {
                    itemMeta19.setDisplayName(ChatColor.GREEN + Messages.ferrariSnakeKitName);
                    final ArrayList<String> lore5 = new ArrayList<String>();
                    lore5.add(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.itemAlreadyOwned));
                    itemMeta19.setLore((List)lore5);
                }
                else {
                    final ArrayList<String> lore6 = new ArrayList<String>();
                    lore6.add(new StringBuilder().append(ChatColor.GREEN).append(FileManager.ferrariSnakePrice).append(" ").append(EconomyManager.economy.currencyNamePlural()).toString());
                    itemMeta19.setLore((List)lore6);
                    itemMeta19.setDisplayName(ChatColor.RED + Messages.ferrariSnakeKitName);
                }
                itemStack17.setItemMeta(itemMeta17);
                itemStack18.setItemMeta(itemMeta18);
                itemStack19.setItemMeta(itemMeta19);
                final Inventory inventory2 = Bukkit.createInventory((InventoryHolder)null, 9, ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.guiShopItemName));
                inventory2.setItem(8, itemStack17);
                inventory2.setItem(0, itemStack18);
                inventory2.setItem(1, itemStack19);
                player.openInventory(inventory2);
            }
        }
    }
    
    public static void onThrowAway(final PlayerDropItemEvent playerDropItemEvent) {
        if ((ArenaManager.getManager().searchForPlayer(playerDropItemEvent.getPlayer()) && playerDropItemEvent.getItemDrop().getItemStack().getType() == Material.STAINED_GLASS_PANE) || (ArenaManager.getManager().searchForPlayer(playerDropItemEvent.getPlayer()) && playerDropItemEvent.getItemDrop().getItemStack().getType() == Material.NAME_TAG)) {
            playerDropItemEvent.setCancelled(true);
        }
    }
    
    public static void givePlayerNametag(final Player player) {
        if (!ShopManager.findPlayerInColorChooser(player.getUniqueId())) {
            return;
        }
        final ItemStack itemStack = new ItemStack(Material.NAME_TAG);
        final ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.setDisplayName(ChatColor.DARK_PURPLE + Messages.colorChooserName);
        itemStack.setItemMeta(itemMeta);
        player.getInventory().setItem(0, itemStack);
    }
    
    public static void givePlayerStainedGlass(final Player player) {
        final ItemStack itemStack = new ItemStack(Material.STAINED_GLASS_PANE, 1, (short)14);
        final ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.setDisplayName(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.leaveArenaGuiItem));
        itemStack.setItemMeta(itemMeta);
        player.getInventory().setItem(8, itemStack);
        player.updateInventory();
    }
    
    public static void givePlayerShop(final Player player) {
        final ItemStack itemStack = new ItemStack(Material.DIAMOND, 1);
        final ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.setDisplayName(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.guiShopItemName));
        itemStack.setItemMeta(itemMeta);
        player.getInventory().setItem(7, itemStack);
        player.updateInventory();
    }
    
    @EventHandler(priority = EventPriority.NORMAL)
    public void onInventoryClick(final InventoryClickEvent inventoryClickEvent) {
        final Player player = (Player)inventoryClickEvent.getWhoClicked();
        final ItemStack currentItem = inventoryClickEvent.getCurrentItem();
        final Inventory inventory = inventoryClickEvent.getInventory();
        if (currentItem == null || currentItem.getType() == null) {
            return;
        }
        if (!ArenaManager.getManager().searchForPlayer(player)) {
            return;
        }
        inventoryClickEvent.setCancelled(true);
        if (inventory.getName().contains(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.guiShopItemName))) {
            if (currentItem.getType().equals((Object)Material.FEATHER)) {
                if (((String)currentItem.getItemMeta().getLore().get(0)).contains(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.itemAlreadyOwned))) {
                    if (currentItem.getItemMeta().getDisplayName().contains(Messages.fastSnakeKitName)) {
                        ShopManager.selected.put(player.getUniqueId(), "fastsnake");
                    }
                    if (currentItem.getItemMeta().getDisplayName().contains(Messages.ferrariSnakeKitName)) {
                        ShopManager.selected.put(player.getUniqueId(), "ferrarisnake");
                    }
                    player.sendMessage(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.selectedKitMessage.replace("[X]", currentItem.getItemMeta().getDisplayName())));
                    player.closeInventory();
                    inventoryClickEvent.setCancelled(true);
                    return;
                }
                if (currentItem.getItemMeta().getDisplayName().contains(Messages.fastSnakeKitName)) {
                    if (EconomyManager.economy.withdrawPlayer((OfflinePlayer)player, (double)FileManager.fastSnakePrice).transactionSuccess()) {
                        List<String> list = ShopManager.owned.get(player.getUniqueId());
                        if (list == null) {
                            list = new ArrayList<String>();
                        }
                        list.add("fastsnake");
                        ShopManager.owned.put(player.getUniqueId(), list);
                        ShopManager.selected.put(player.getUniqueId(), "fastsnake");
                        player.sendMessage(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.purchasedAndSelectedMessage.replace("[X]", currentItem.getItemMeta().getDisplayName())));
                    }
                    else {
                        player.sendMessage(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.errorInsufficiantFunds));
                    }
                    inventoryClickEvent.setCancelled(true);
                    player.closeInventory();
                    return;
                }
                if (currentItem.getItemMeta().getDisplayName().contains(Messages.ferrariSnakeKitName)) {
                    if (EconomyManager.economy.withdrawPlayer((OfflinePlayer)player, (double)FileManager.ferrariSnakePrice).transactionSuccess()) {
                        List<String> list2 = ShopManager.owned.get(player.getUniqueId());
                        if (list2 == null) {
                            list2 = new ArrayList<String>();
                        }
                        list2.add("ferrarisnake");
                        ShopManager.owned.put(player.getUniqueId(), list2);
                        ShopManager.selected.put(player.getUniqueId(), "ferrarisnake");
                        player.sendMessage(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.purchasedAndSelectedMessage.replace("[X]", currentItem.getItemMeta().getDisplayName())));
                    }
                    else {
                        player.sendMessage(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.errorInsufficiantFunds));
                    }
                    inventoryClickEvent.setCancelled(true);
                    player.closeInventory();
                    return;
                }
            }
            if (currentItem.getType() == Material.NAME_TAG) {
                if (ShopManager.findPlayerInColorChooser(player.getUniqueId())) {
                    inventoryClickEvent.setCancelled(true);
                    player.sendMessage(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.itemAlreadyOwned));
                    return;
                }
                if (!((String)currentItem.getItemMeta().getLore().get(0)).contains(Messages.itemAlreadyOwned) && currentItem.getItemMeta().getDisplayName().contains(Messages.colorChooserName)) {
                    if (EconomyManager.economy.withdrawPlayer((OfflinePlayer)player, (double)FileManager.priceColorChooser).transactionSuccess()) {
                        ShopManager.colorChooser.put(player.getUniqueId(), true);
                        player.sendMessage(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.purchaseColorChooser));
                        givePlayerNametag(player);
                    }
                    else {
                        player.sendMessage(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.errorInsufficiantFunds));
                    }
                    inventoryClickEvent.setCancelled(true);
                    player.closeInventory();
                    return;
                }
            }
        }
        if (inventory.getName().equalsIgnoreCase(Messages.colorChooserName) && currentItem.getType() == Material.WOOL) {
            ArenaManager.getManager().getPlayersArena(player).getIArena().replaceHashMapAlpha(player, (int)currentItem.getData().getData());
            player.sendMessage(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.selectedColorMessage.replace("[X]", Main.nmsAccess.numToEc(currentItem.getData().getData()).toString())));
            inventoryClickEvent.setCancelled(true);
            player.closeInventory();
        }
    }
}
