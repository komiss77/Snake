// 
// Decompiled by Procyon v0.5.30
// 

package com.dumbninja22.supersnake.ninjagamesAPI;

import java.io.IOException;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.plugin.Plugin;
import org.bukkit.Bukkit;
import java.util.ArrayList;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.event.EventPriority;
import org.bukkit.event.EventHandler;
import java.util.Iterator;
import org.bukkit.entity.Player;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.GameMode;
import java.util.Map;
import org.bukkit.block.Sign;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.configuration.file.YamlConfiguration;
import com.dumbninja22.supersnake.Main;
import java.util.List;
import org.bukkit.configuration.file.FileConfiguration;
import java.io.File;
import org.bukkit.Location;
import java.util.HashMap;
import org.bukkit.event.Listener;

public class SignManager implements Listener
{
    public static HashMap<Location, String> serverfrom;
    public static HashMap<Location, String> serverto;
    static File signYml;
    static FileConfiguration signConfig;
    static HashMap<String, List<Location>> signLocs;
    
    static {
        SignManager.serverfrom = new HashMap<Location, String>();
        SignManager.serverto = new HashMap<Location, String>();
        SignManager.signYml = new File(((Main)Main.getPlugin((Class)Main.class)).getDataFolder() + "/SSSigns.yml");
        SignManager.signConfig = (FileConfiguration)YamlConfiguration.loadConfiguration(SignManager.signYml);
        SignManager.signLocs = new HashMap<String, List<Location>>();
    }
    
    @EventHandler(priority = EventPriority.LOW)
    public static void onSignClick(final PlayerInteractEvent playerInteractEvent) {
        final Player player = playerInteractEvent.getPlayer();
        String s = null;
        if ((playerInteractEvent.getAction() == Action.RIGHT_CLICK_BLOCK || playerInteractEvent.getAction() == Action.LEFT_CLICK_BLOCK) && playerInteractEvent.getClickedBlock().getState() instanceof Sign) {
            for (final Map.Entry<String, List<Location>> entry : SignManager.signLocs.entrySet()) {
                final List<Location> list = entry.getValue();
                if (list != null && list.contains(playerInteractEvent.getClickedBlock().getLocation())) {
                    s = entry.getKey();
                }
            }
            if (s == null) {
                return;
            }
            if (((player.getGameMode() == GameMode.CREATIVE && player.hasPermission("supersnake.arenacreation")) || (player.getGameMode() == GameMode.CREATIVE && player.isOp())) && playerInteractEvent.getAction() == Action.LEFT_CLICK_BLOCK) {
                playerInteractEvent.getClickedBlock().getLocation().getBlock().setType(Material.AIR);
                SignManager.signLocs.get(s).remove(playerInteractEvent.getClickedBlock().getLocation());
                if (MySQLManager.sqlEnabled && FileManager.bungee) {
                    MySQLManager.deleteFromSQLArenaSignLocations(playerInteractEvent.getClickedBlock().getLocation());
                    SignManager.serverfrom.remove(playerInteractEvent.getClickedBlock().getLocation());
                    SignManager.serverto.remove(playerInteractEvent.getClickedBlock().getLocation());
                }
                player.sendMessage(ChatColor.BLUE + "You have deleted this join sign!");
                return;
            }
            if (FileManager.bungee && MySQLManager.sqlEnabled) {
                if (!SignManager.serverto.containsKey(playerInteractEvent.getClickedBlock().getLocation())) {
                    return;
                }
                if (!SignManager.serverto.get(playerInteractEvent.getClickedBlock().getLocation()).equals(MySQLManager.bungee.getServerName(player))) {
                    for (final Location location : SignManager.signLocs.get(s)) {
                        if (location.getBlock().getState() instanceof Sign) {
                            final Sign sign = (Sign)location.getBlock().getState();
                            final String line = sign.getLine(1);
                            int char1 = line.charAt(0);
                            sign.setLine(1, line.replace(String.valueOf(char1).charAt(0), String.valueOf(char1++).charAt(0)));
                        }
                    }
                    MySQLManager.bungee.joinPlayerArena(player, s, SignManager.serverto.get(playerInteractEvent.getClickedBlock().getLocation()));
                    return;
                }
            }
            ArenaManager.getManager().addPlayer(player, s);
            playerInteractEvent.setCancelled(true);
        }
    }
    
    @EventHandler
    public static void onSignCreate(final SignChangeEvent signChangeEvent) {
        final String[] lines = signChangeEvent.getLines();
        final Player player = signChangeEvent.getPlayer();
        if (lines[0].equalsIgnoreCase("Super Snake") && !lines[1].isEmpty() && (player.hasPermission("supersnake.arenacreation") || player.isOp())) {
            if (signChangeEvent.getBlock().getType() != Material.WALL_SIGN) {
                player.sendMessage(ChatColor.RED + "Only wall signs are allowed!");
                signChangeEvent.setCancelled(true);
                return;
            }
            final Arena arena = ArenaManager.getManager().getArena(lines[1]);
            if (arena != null && !FileManager.bungee) {
                List<Location> list = new ArrayList<Location>();
                final List<Location> list2 = SignManager.signLocs.get(arena.getId());
                if (list2 != null) {
                    list = list2;
                }
                list.add(signChangeEvent.getBlock().getLocation());
                SignManager.serverto.put(signChangeEvent.getBlock().getLocation(), "none");
                SignManager.serverfrom.put(signChangeEvent.getBlock().getLocation(), "none");
                SignManager.signLocs.put(arena.getId(), list);
                signChangeEvent.setLine(0, ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.firstLineOfSign));
                signChangeEvent.setLine(1, new StringBuilder().append(ChatColor.AQUA).append(ChatColor.ITALIC).append("0/").append(arena.maxplayers).toString());
                signChangeEvent.setLine(2, "");
                signChangeEvent.setLine(3, "");
            }
            else if (FileManager.bungee && MySQLManager.sqlEnabled) {
                if (MySQLManager.doesArenaExistInDatabase(lines[1])) {
                    final String serverName = MySQLManager.bungee.getServerName(player);
                    final String arenaHomeServer = MySQLManager.getArenaHomeServer(lines[1]);
                    SignManager.serverto.put(signChangeEvent.getBlock().getLocation(), arenaHomeServer);
                    SignManager.serverfrom.put(signChangeEvent.getBlock().getLocation(), serverName);
                    MySQLManager.addToSQLArenaSignLocations(signChangeEvent.getBlock().getLocation(), lines[1], player, arenaHomeServer);
                    List<Location> list3 = new ArrayList<Location>();
                    final String s = lines[1];
                    final List<Location> list4 = SignManager.signLocs.get(s);
                    if (list4 != null) {
                        list3 = list4;
                    }
                    list3.add(signChangeEvent.getBlock().getLocation());
                    SignManager.signLocs.put(s, list3);
                    signChangeEvent.setLine(0, ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.firstLineOfSign));
                    signChangeEvent.setLine(1, new StringBuilder().append(ChatColor.AQUA).append(ChatColor.ITALIC).append("0/").append(String.valueOf(MySQLManager.getArenaMaxPlayers(s))).toString());
                    signChangeEvent.setLine(2, "");
                    signChangeEvent.setLine(3, "");
                }
                else {
                    player.sendMessage(ChatColor.RED + "Invalid Arena!");
                }
            }
            else {
                player.sendMessage(ChatColor.RED + "Invalid Arena!");
            }
        }
    }
    
    public static void updateSigns(final String s, final int n, final int n2) {
        String s2 = null;
        List<Location> list = new ArrayList<Location>();
        for (final Map.Entry<String, List<Location>> entry : SignManager.signLocs.entrySet()) {
            if (entry.getKey().toString().equals(s.toString())) {
                s2 = s;
                list = entry.getValue();
            }
        }
        if (s2 == null && list.size() == 0) {
            return;
        }
        for (final Location location : list) {
            if (location.getBlock().getState() instanceof Sign) {
                final Sign sign = (Sign)location.getBlock().getState();
                sign.setLine(1, new StringBuilder().append(ChatColor.AQUA).append(ChatColor.ITALIC).append(n).append("/").append(n2).toString());
                sign.update();
            }
        }
    }
    
    public static void registerListener() {
        Bukkit.getServer().getPluginManager().registerEvents((Listener)new SignManager(), (Plugin)Main.getPlugin((Class)Main.class));
    }
    
    public static void loadFile() {
        try {
            final ConfigurationSection configurationSection = SignManager.signConfig.getConfigurationSection("signs");
            final HashMap<String, List<String>> hashMap = new HashMap<String, List<String>>();
            final HashMap<String, ArrayList<Location>> signLocs = (HashMap<String, ArrayList<Location>>)new HashMap<String, List<Location>>();
            for (final String s : configurationSection.getKeys(false)) {
                hashMap.put(s, configurationSection.getStringList(s));
                final ArrayList<Location> list = new ArrayList<Location>();
                final Iterator<String> iterator2 = hashMap.get(s).iterator();
                while (iterator2.hasNext()) {
                    list.add(Utils.stringToLoc(iterator2.next()));
                }
                signLocs.put(s, list);
            }
            if (signLocs.size() > 0) {
                SignManager.signLocs = (HashMap<String, List<Location>>)signLocs;
                Bukkit.getLogger().info("Loaded " + SignManager.signLocs.size() + " sign(s)!");
            }
        }
        catch (NullPointerException ex) {}
    }
    
    public static void savefile() {
        for (final Map.Entry<String, List<Location>> entry : SignManager.signLocs.entrySet()) {
            final ArrayList<String> list = new ArrayList<String>();
            final Iterator<Location> iterator2 = entry.getValue().iterator();
            while (iterator2.hasNext()) {
                list.add(Utils.locToString(iterator2.next()));
            }
            SignManager.signConfig.set("signs." + entry.getKey(), (Object)list);
        }
        try {
            SignManager.signConfig.save(SignManager.signYml);
        }
        catch (IOException ex) {}
    }
}
