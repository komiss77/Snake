// 
// Decompiled by Procyon v0.5.30
// 

package com.dumbninja22.supersnake.ninjagamesAPI;

import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.Bukkit;
import net.milkbowl.vault.economy.Economy;

public class EconomyManager
{
    public static Economy economy;
    
    static {
        EconomyManager.economy = null;
    }
    
    public static boolean setupEconomy() {
        if (Bukkit.getServer().getPluginManager().getPlugin("Vault") != null) {
            final RegisteredServiceProvider registration = Bukkit.getServer().getServicesManager().getRegistration((Class)Economy.class);
            if (registration != null) {
                EconomyManager.economy = (Economy)registration.getProvider();
            }
        }
        return EconomyManager.economy != null;
    }
}
