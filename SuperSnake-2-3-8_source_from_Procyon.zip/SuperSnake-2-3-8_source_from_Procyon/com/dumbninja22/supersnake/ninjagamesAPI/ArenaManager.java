// 
// Decompiled by Procyon v0.5.30
// 

package com.dumbninja22.supersnake.ninjagamesAPI;

import org.bukkit.Material;
import com.dumbninja22.supersnake.Minigame;
import com.google.gson.JsonObject;
import org.bukkit.event.EventPriority;
import org.bukkit.ChatColor;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.EventHandler;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.util.Vector;
import java.util.Iterator;
import org.bukkit.plugin.Plugin;
import org.bukkit.Bukkit;
import java.util.ArrayList;
import java.util.HashMap;
import com.dumbninja22.supersnake.Main;
import java.util.List;
import org.bukkit.GameMode;
import org.bukkit.inventory.ItemStack;
import org.bukkit.Location;
import java.util.UUID;
import java.util.Map;
import org.bukkit.event.Listener;

public class ArenaManager implements Listener
{
    private static ArenaManager am;
    private final Map<UUID, Location> locs;
    private final Map<UUID, ItemStack[]> inv;
    private final Map<UUID, ItemStack[]> armor;
    private final Map<UUID, Integer> level;
    private final Map<UUID, Float> xp;
    private final Map<UUID, GameMode> gamemodes;
    private final List<Arena> arenas;
    int arenaSize;
    Main plugin;
    int joinnumber;
    int jointask;
    
    private ArenaManager() {
        this.locs = new HashMap<UUID, Location>();
        this.inv = new HashMap<UUID, ItemStack[]>();
        this.armor = new HashMap<UUID, ItemStack[]>();
        this.level = new HashMap<UUID, Integer>();
        this.xp = new HashMap<UUID, Float>();
        this.gamemodes = new HashMap<UUID, GameMode>();
        this.arenas = new ArrayList<Arena>();
        this.arenaSize = 0;
    }
    
    public static ArenaManager getManager() {
        if (ArenaManager.am == null) {
            ArenaManager.am = new ArenaManager();
        }
        return ArenaManager.am;
    }
    
    public ArenaManager(final Main plugin) {
        this.locs = new HashMap<UUID, Location>();
        this.inv = new HashMap<UUID, ItemStack[]>();
        this.armor = new HashMap<UUID, ItemStack[]>();
        this.level = new HashMap<UUID, Integer>();
        this.xp = new HashMap<UUID, Float>();
        this.gamemodes = new HashMap<UUID, GameMode>();
        this.arenas = new ArrayList<Arena>();
        this.arenaSize = 0;
        this.plugin = plugin;
    }
    
    public void registerListener() {
        Bukkit.getServer().getPluginManager().registerEvents((Listener)getManager(), (Plugin)Main.getPlugin((Class)Main.class));
    }
    
    public Arena getArena(final String s) {
        for (final Arena arena : this.arenas) {
            if (arena.getId().equals(s)) {
                return arena;
            }
        }
        return null;
    }
    
    public static boolean isInside(final Location location, final Vector vector, final Vector vector2) {
        final int min = Math.min(vector.getBlockX(), vector2.getBlockX());
        final int min2 = Math.min(vector.getBlockZ(), vector2.getBlockZ());
        final int max = Math.max(vector.getBlockX(), vector2.getBlockX());
        final int max2 = Math.max(vector.getBlockZ(), vector2.getBlockZ());
        return location.getX() >= min && location.getX() <= max && location.getZ() >= min2 && location.getZ() <= max2;
    }
    
    @EventHandler
    public void playerLeave(final PlayerQuitEvent playerQuitEvent) {
        final Player player = playerQuitEvent.getPlayer();
        Arena arena = null;
        for (final Arena arena2 : this.arenas) {
            if (arena2.getPlayers().contains(player.getUniqueId())) {
                arena = arena2;
            }
        }
        if (arena == null) {
            return;
        }
        this.removePlayer(player, false);
    }
    
    @EventHandler
    public void noHurt(final EntityDamageEvent entityDamageEvent) {
        if (entityDamageEvent.getEntity() instanceof Player && this.searchForPlayer((Player)entityDamageEvent.getEntity())) {
            entityDamageEvent.setCancelled(true);
        }
    }
    
    public void joiner(final Player player) {
        this.jointask = ((Main)Main.getPlugin((Class)Main.class)).getServer().getScheduler().scheduleSyncRepeatingTask((Plugin)Main.getPlugin((Class)Main.class), (Runnable)new Runnable() {
            @Override
            public void run() {
                if (ArenaManager.this.joinnumber > -1 && ArenaManager.this.joinnumber != -250) {
                    if (ArenaManager.this.joinnumber != 0) {
                        if (ArenaManager.this.joinnumber == 1) {
                            MySQLManager.bungee.initGetServerName(player);
                        }
                        final ArenaManager this$0 = ArenaManager.this;
                        --this$0.joinnumber;
                    }
                    else {
                        ArenaManager.this.joinnumber = -250;
                        Bukkit.getServer().getScheduler().cancelTask(ArenaManager.this.jointask);
                        MySQLManager.bungee.getServerName(player);
                        final String serverName = MySQLManager.bungee.getServerName(player);
                        final ArrayList<String> list = new ArrayList<String>();
                        for (final Map.Entry<String, List<Location>> entry : SignManager.signLocs.entrySet()) {
                            final Iterator<Location> iterator2 = entry.getValue().iterator();
                            while (iterator2.hasNext()) {
                                if (!SignManager.serverfrom.get(iterator2.next()).equals(serverName)) {
                                    list.add(entry.getKey());
                                }
                            }
                        }
                        for (final String s : list) {
                            SignManager.signLocs.remove(s);
                            SignManager.serverto.remove(Utils.stringToLoc(s));
                            SignManager.serverfrom.remove(Utils.stringToLoc(s));
                        }
                        final ArrayList<Arena> list2 = new ArrayList<Arena>();
                        for (final Arena arena : ArenaManager.getManager().getAllArenas()) {
                            if (!arena.getServerId().equals(serverName)) {
                                list2.add(arena);
                            }
                        }
                        final Iterator<Object> iterator5 = list2.iterator();
                        while (iterator5.hasNext()) {
                            ArenaManager.this.arenas.remove(iterator5.next());
                        }
                        list2.clear();
                        MySQLManager.playerjoined = true;
                    }
                }
                else {
                    Bukkit.getServer().getScheduler().cancelTask(ArenaManager.this.jointask);
                }
            }
        }, 0L, 20L);
    }
    
    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(final PlayerJoinEvent playerJoinEvent) {
        if (MySQLManager.sqlEnabled && FileManager.bungee && !MySQLManager.playerjoined) {
            this.joinnumber = 3;
            this.joiner(playerJoinEvent.getPlayer());
        }
        if (!MySQLManager.arenaToSendPlayerAfterJoining.equals("none")) {
            try {
                getManager().addPlayer(playerJoinEvent.getPlayer(), MySQLManager.arenaToSendPlayerAfterJoining);
            }
            catch (Exception ex) {
                Utils.echo("Unable to find the arena to put the player in upon entry. If you do not wish to put a player in an arena on entry, return the value back to 'none'");
            }
        }
        if (MySQLManager.sqlEnabled && FileManager.bungee) {
            final String playerWaitingToJoin = MySQLManager.isPlayerWaitingToJoin(playerJoinEvent.getPlayer().getDisplayName());
            if (!playerWaitingToJoin.equals("no")) {
                final Arena arena = getManager().getArena(playerWaitingToJoin);
                if (!getManager().getAllArenas().contains(arena)) {
                    return;
                }
                if (arena == null) {
                    playerJoinEvent.getPlayer().sendMessage(ChatColor.RED + "Unable to join arena! Invalid! The arena id was: " + playerWaitingToJoin);
                    return;
                }
                getManager().addPlayer(playerJoinEvent.getPlayer(), arena.getId());
            }
        }
    }
    
    public List<Arena> getAllArenas() {
        return this.arenas;
    }
    
    public void addPlayer(final Player player, final String s) {
        final Arena arena = this.getArena(s);
        if (arena == null) {
            player.sendMessage(ChatColor.RED + "Invalid Arena");
            return;
        }
        if (this.isInGame(player)) {
            player.sendMessage(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.errorJoinMoreThenOneArena));
            return;
        }
        if (arena.getArenaLobby() == null) {
            player.sendMessage("This arena has no lobby. Invalid Arena.");
            return;
        }
        if (arena.getSpawns() == null || arena.getSpawns().size() == 0) {
            player.sendMessage("This arena has no spawn points. Invalid Arena.");
            return;
        }
        if (arena.getBoundsLow() == null || arena.getBoundsHigh() == null) {
            player.sendMessage("You forgot to set your arena bounds");
            return;
        }
        if (arena.getMainLobby() == null) {
            player.sendMessage("You forgot to set your main lobby");
            return;
        }
        if (arena.getArenaLobby() == null) {
            player.sendMessage("You forgot to set your waiting lobby");
            return;
        }
        if (arena.getPlayers().size() + 1 > arena.getSpawns().size()) {
            player.sendMessage(ChatColor.RED + "Arena Full!");
            return;
        }
        if (arena.getId() == null) {
            player.sendMessage("You forgot to set your arena's name. Please delete it from your config and try creating it again.");
            return;
        }
        if (arena.getIArena().hasStarted()) {
            player.sendMessage(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.gameAlreadyStarted));
            return;
        }
        try {
            for (final Arena arena2 : getManager().getAllArenas()) {
                if (!arena2.getId().equals(arena.getId())) {
                    if (isInside(arena2.getSpawns().get(0), arena.getBoundsLow().toVector(), arena.getBoundsHigh().toVector())) {
                        player.sendMessage(ChatColor.RED + "You are unable to join this arena because it overlaps another arena. Please inform the admin of this error.");
                        return;
                    }
                    if (isInside(arena2.getSpawns().get(1), arena.getBoundsLow().toVector(), arena.getBoundsHigh().toVector())) {
                        player.sendMessage(ChatColor.RED + "You are unable to join this arena because it overlaps another arena. Please inform the admin of this error.");
                        return;
                    }
                    continue;
                }
            }
        }
        catch (Exception ex) {}
        arena.getPlayers().add(player.getUniqueId());
        this.inv.put(player.getUniqueId(), player.getInventory().getContents());
        this.armor.put(player.getUniqueId(), player.getInventory().getArmorContents());
        this.xp.put(player.getUniqueId(), player.getExp());
        this.level.put(player.getUniqueId(), player.getLevel());
        this.gamemodes.put(player.getUniqueId(), player.getGameMode());
        player.getInventory().setArmorContents((ItemStack[])null);
        player.getInventory().clear();
        player.getInventory().setHeldItemSlot(1);
        this.locs.put(player.getUniqueId(), player.getLocation());
        player.sendMessage(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.playerJoinArena));
        player.teleport(arena.getArenaLobby());
        arena.getIArena().joinPlayerLobby(player, (Plugin)Main.getPlugin((Class)Main.class));
        GUIManager.givePlayerStainedGlass(player);
        if (EconomyManager.economy != null) {
            GUIManager.givePlayerShop(player);
        }
        if (arena.getPlayers().size() == arena.getMinPlayers()) {
            arena.numberII = 30;
            arena.startCountdownII();
        }
        SignManager.updateSigns(s, arena.getPlayers().size(), arena.maxplayers);
        if (FileManager.bungee && MySQLManager.sqlEnabled) {
            MySQLManager.bungee.updateUniversalSigns(player, arena.getId(), arena.getPlayers().size(), arena.maxplayers);
            MySQLManager.unsetPlayerWaitingToJoinArena(player.getDisplayName());
        }
    }
    
    public void removePlayer(final Player player, final boolean b) {
        Arena arena = null;
        for (final Arena arena2 : this.arenas) {
            if (arena2.getPlayers().contains(player.getUniqueId())) {
                arena = arena2;
            }
        }
        if (arena == null) {
            return;
        }
        if (player == null) {
            echo("Error AM370");
            return;
        }
        int size = arena.getPlayers().size();
        --size;
        final Minigame iArena = arena.getIArena();
        arena.removeFromFrozenPlayers(player);
        arena.removePlayerFromList(player.getUniqueId());
        player.getInventory().clear();
        player.getInventory().setArmorContents((ItemStack[])null);
        player.updateInventory();
        player.setScoreboard(Bukkit.getScoreboardManager().getNewScoreboard());
        SignManager.updateSigns(arena.getId(), size, arena.maxplayers);
        if (FileManager.bungee && MySQLManager.sqlEnabled) {
            MySQLManager.bungee.updateUniversalSigns(player, arena.getId(), size, arena.maxplayers);
            MySQLManager.unsetPlayerWaitingToJoinArena(player.getDisplayName());
        }
        player.getInventory().setContents((ItemStack[])this.inv.get(player.getUniqueId()));
        player.getInventory().setArmorContents((ItemStack[])this.armor.get(player.getUniqueId()));
        player.setLevel((int)this.level.get(player.getUniqueId()));
        player.setExp((float)this.xp.get(player.getUniqueId()));
        player.setGameMode((GameMode)this.gamemodes.get(player.getUniqueId()));
        this.inv.remove(player.getUniqueId());
        this.armor.remove(player.getUniqueId());
        this.level.remove(player.getUniqueId());
        this.xp.remove(player.getUniqueId());
        this.gamemodes.remove(player.getUniqueId());
        if (!b) {
            arena.getIArena().leavePlayer(player, true);
        }
        arena.getIArena().ism.removePlayer(player);
        if (MySQLManager.serverToSendPlayerAfterGame.equals("none")) {
            player.teleport(arena.getMainLobby());
        }
        else if (FileManager.bungee) {
            new DelayEffect(4, player, MySQLManager.serverToSendPlayerAfterGame);
        }
        if (size >= 1 && iArena.hasStarted()) {
            final JsonObject jsonObject = new JsonObject();
            jsonObject.addProperty("text", Messages.titleMessageLose);
            jsonObject.addProperty("color", "red");
            Main.nmsAccess.showTitle(jsonObject.toString(), player);
        }
        player.setFireTicks(0);
        if (size < arena.getMinPlayers() && !iArena.hasStarted()) {
            if (arena.taskII != null) {
                arena.taskII.cancel();
            }
            arena.numberII = -250;
        }
        else if (size < 2 && arena.getIArena().hasStarted()) {
            this.omegaTermination(arena);
        }
    }
    
    public boolean searchForPlayer(final Player player) {
        Arena arena = null;
        for (final Arena arena2 : this.arenas) {
            if (arena2.getPlayers().contains(player.getUniqueId())) {
                arena = arena2;
            }
        }
        return arena != null;
    }
    
    public Arena getPlayersArena(final Player player) {
        Arena arena = null;
        for (final Arena arena2 : this.arenas) {
            if (arena2.getPlayers().contains(player.getUniqueId())) {
                arena = arena2;
            }
        }
        if (arena == null) {
            return null;
        }
        if (player == null) {
            return null;
        }
        return arena;
    }
    
    public String getServerId(final Arena arena) {
        return arena.getServerId();
    }
    
    public static void echo(final String s) {
        Bukkit.getLogger().info(s);
    }
    
    public Arena createArena(final Location location, final String s, final Player player) {
        ++this.arenaSize;
        final ArrayList<Location> list = new ArrayList<Location>();
        list.add(location);
        final Minigame minigame = new Minigame(null);
        String serverName = "none";
        if (FileManager.bungee && MySQLManager.sqlEnabled) {
            serverName = MySQLManager.bungee.getServerName(player);
        }
        final Arena officialArena = new Arena(list, s, minigame, null, null, null, null, serverName);
        minigame.setOfficialArena(officialArena);
        this.arenas.add(officialArena);
        return officialArena;
    }
    
    public Arena massCreateArena(final List<Location> list, final String s, final Location location, final Location location2, final Location location3, final Location location4, final Plugin plugin, final String s2) {
        if (!plugin.getName().equals(((Main)Main.getPlugin((Class)Main.class)).getName())) {
            return null;
        }
        ++this.arenaSize;
        final Minigame minigame = new Minigame(null);
        final Arena officialArena = new Arena(list, s, minigame, location, location2, location3, location4, s2);
        minigame.setOfficialArena(officialArena);
        this.arenas.add(officialArena);
        return officialArena;
    }
    
    public Arena reloadArena(final List<Location> list, final String s, final String s2) {
        ++this.arenaSize;
        final Minigame minigame = new Minigame(null);
        final Arena officialArena = new Arena(list, s, minigame, new Location(Bukkit.getWorld("world"), 0.0, 0.0, 0.0), new Location(Bukkit.getWorld("world"), 0.0, 0.0, 0.0), new Location(Bukkit.getWorld("world"), 0.0, 0.0, 0.0), new Location(Bukkit.getWorld("world"), 0.0, 0.0, 0.0), s2);
        minigame.setOfficialArena(officialArena);
        this.arenas.add(officialArena);
        return officialArena;
    }
    
    public void removeArena(final String s) {
        final Arena arena = this.getArena(s);
        if (arena == null) {
            return;
        }
        this.arenas.remove(arena);
        if (MySQLManager.sqlEnabled) {
            for (final Location location : SignManager.signLocs.get(s)) {
                location.getBlock().setType(Material.AIR);
                MySQLManager.deleteFromSQLArenaSignLocations(location);
            }
            MySQLManager.deleteAllArenaSignsFromSQL(s);
            MySQLManager.deleteArenaFromSQL(s);
        }
        else {
            FileManager.customConfig.set("SSArenas." + s, (Object)null);
            FileManager.customConfig.set("mainLobby." + s, (Object)null);
            FileManager.customConfig.set("arenaLobby." + s, (Object)null);
            FileManager.customConfig.set("boundsLow." + s, (Object)null);
            FileManager.customConfig.set("boundsHigh." + s, (Object)null);
            ((Main)Main.getPlugin((Class)Main.class)).getConfig().set("minPlayers." + s, (Object)null);
            SignManager.signLocs.remove(s);
            SignManager.signConfig.set("signs." + s, (Object)null);
            Utils.saveCustomYml(SignManager.signConfig, SignManager.signYml);
            Utils.saveCustomYml(FileManager.customConfig, FileManager.customYml);
            ((Main)Main.getPlugin((Class)Main.class)).saveConfig();
        }
    }
    
    public boolean isInGame(final Player player) {
        final Iterator<Arena> iterator = this.arenas.iterator();
        while (iterator.hasNext()) {
            if (iterator.next().getPlayers().contains(player.getUniqueId())) {
                return true;
            }
        }
        return false;
    }
    
    public void setBoundsHigh(final Location boundsHigh, final String s) {
        this.getArena(s).setBoundsHigh(boundsHigh);
    }
    
    public void setArenaLobby(final Location arenaLobby, final String s) {
        this.getArena(s).setArenaLobby(arenaLobby);
    }
    
    private void killAllPlayers(final Arena arena) {
        final ArrayList<UUID> list = new ArrayList<UUID>();
        for (final UUID uuid : arena.getPlayers()) {
            if (uuid != null) {
                final Player playerByUUID = Utils.getPlayerByUUID(uuid);
                playerByUUID.getInventory().clear();
                playerByUUID.getInventory().setArmorContents((ItemStack[])null);
                playerByUUID.updateInventory();
                playerByUUID.getInventory().setContents((ItemStack[])this.inv.get(uuid));
                playerByUUID.getInventory().setArmorContents((ItemStack[])this.armor.get(uuid));
                playerByUUID.setGameMode((GameMode)this.gamemodes.get(uuid));
                playerByUUID.setLevel((int)this.level.get(uuid));
                playerByUUID.setExp((float)this.xp.get(uuid));
                playerByUUID.setScoreboard(Bukkit.getScoreboardManager().getNewScoreboard());
                playerByUUID.updateInventory();
                this.inv.remove(uuid);
                this.armor.remove(uuid);
                this.gamemodes.remove(uuid);
                this.xp.remove(uuid);
                this.level.remove(uuid);
                arena.getIArena().ism.removePlayer(playerByUUID);
                arena.getIArena().leavePlayer(playerByUUID, true);
                if (FileManager.bungee) {
                    new DelayEffect(4, playerByUUID, MySQLManager.serverToSendPlayerAfterGame);
                }
                else {
                    playerByUUID.teleport(arena.getMainLobby());
                }
                this.locs.remove(uuid);
                playerByUUID.setFireTicks(0);
                list.add(uuid);
            }
        }
        final Iterator<Object> iterator2 = list.iterator();
        while (iterator2.hasNext()) {
            arena.removePlayerFromList(iterator2.next());
        }
    }
    
    public void stopArena(final String s, final Player player) {
        final Arena arena = this.getArena(s);
        if (arena == null) {
            return;
        }
        this.killAllPlayers(arena);
        this.omegaTermination(arena);
        if (FileManager.bungee && MySQLManager.sqlEnabled) {
            MySQLManager.bungee.updateUniversalSigns(player, arena.getId(), 0, arena.maxplayers);
        }
    }
    
    private void omegaTermination(final Arena arena) {
        arena.setState(GameState.WAITING);
        arena.getIArena().stop();
        SignManager.updateSigns(arena.getId(), 0, arena.maxplayers);
    }
    
    public void startArena(final String s) {
        final Arena arena = this.getArena(s);
        final Iterator<UUID> iterator = arena.getPlayers().iterator();
        while (iterator.hasNext()) {
            final Player playerByUUID = Utils.getPlayerByUUID(iterator.next());
            playerByUUID.closeInventory();
            playerByUUID.getInventory().clear();
            playerByUUID.updateInventory();
        }
        arena.initiateStart();
        if (arena.taskII != null) {
            arena.taskII.cancel();
        }
    }
    
    public void setBoundsLow(final Location boundsLow, final String s) {
        final Arena arena = this.getArena(s);
        if (arena == null) {
            return;
        }
        arena.setBoundsLow(boundsLow);
        if (MySQLManager.sqlEnabled) {
            MySQLManager.updateArena(arena);
        }
    }
    
    public void setMainLobby(final Location mainLobby, final String s) {
        final Arena arena = this.getArena(s);
        if (arena == null) {
            return;
        }
        arena.setMainLobby(mainLobby);
        if (MySQLManager.sqlEnabled) {
            MySQLManager.updateArena(arena);
        }
    }
    
    public void addSpawn(final Location location, final String s) {
        final Arena arena = this.getArena(s);
        if (arena == null) {
            return;
        }
        arena.addSpawn(location);
        if (MySQLManager.sqlEnabled) {
            MySQLManager.updateArena(arena);
        }
    }
}
