// 
// Decompiled by Procyon v0.5.30
// 

package com.dumbninja22.supersnake.ninjagamesAPI;

import java.sql.ResultSet;
import org.bukkit.plugin.Plugin;
import java.sql.Connection;

public abstract class Database
{
    protected Connection connection;
    protected Plugin plugin;
    
    protected Database(final Plugin plugin) {
        this.plugin = plugin;
        this.connection = null;
    }
    
    public abstract Connection openConnection();
    
    public boolean checkConnection() {
        return this.connection != null && !this.connection.isClosed();
    }
    
    public Connection getConnection() {
        return this.connection;
    }
    
    public boolean closeConnection() {
        if (this.connection == null) {
            return false;
        }
        this.connection.close();
        return true;
    }
    
    public ResultSet querySQL(final String s) {
        if (!this.checkConnection()) {
            this.openConnection();
        }
        return this.connection.createStatement().executeQuery(s);
    }
    
    public int updateSQL(final String s) {
        if (!this.checkConnection()) {
            this.openConnection();
        }
        return this.connection.createStatement().executeUpdate(s);
    }
}
