// 
// Decompiled by Procyon v0.5.30
// 

package com.dumbninja22.supersnake.ninjagamesAPI;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

public class CommandHandler extends JavaPlugin
{
    public static boolean handleCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        if (array[0].equalsIgnoreCase("join") && commandSender instanceof Player) {
            if (array.length == 2) {
                if (ArenaManager.getManager().getArena(array[1]) == null) {
                    commandSender.sendMessage(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.joinInvalidArenaMessage));
                    return true;
                }
                ArenaManager.getManager().addPlayer((Player)commandSender, array[1]);
            }
            else {
                commandSender.sendMessage(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.joinArenaBadArguments));
            }
            return true;
        }
        if (array[0].equalsIgnoreCase("delete")) {
            if ((array.length == 2 && commandSender.hasPermission("supersnake.arenacreation")) || (array.length == 2 && commandSender.isOp())) {
                if (ArenaManager.getManager().getArena(array[1]) == null) {
                    commandSender.sendMessage(ChatColor.RED + "That arena doesn't exist");
                    return true;
                }
                if (ArenaManager.getManager().getArena(array[1]).getPlayers().size() > 0) {
                    commandSender.sendMessage(ChatColor.RED + "That arena has players in it. Please stop the game before performing this operation.");
                    return true;
                }
                ArenaManager.getManager().removeArena(array[1]);
                commandSender.sendMessage(ChatColor.LIGHT_PURPLE + "You have deleted this arena!");
            }
            else {
                commandSender.sendMessage(ChatColor.RED + "Insufficiant Arguments. Proper use of the command goes like this: /db delete <arena name>");
            }
            return true;
        }
        if (array[0].equalsIgnoreCase("setminplayers")) {
            if (commandSender.hasPermission("supersnake.arenacreation") || commandSender.isOp()) {
                if (array.length == 3) {
                    if (ArenaManager.getManager().getArena(array[1]) == null) {
                        commandSender.sendMessage(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.joinInvalidArenaMessage));
                        return true;
                    }
                    int intValue;
                    try {
                        intValue = Integer.valueOf(array[2]);
                    }
                    catch (Exception ex) {
                        commandSender.sendMessage(ChatColor.RED + "The third argument is not a valid int!");
                        return true;
                    }
                    FileManager.minPlayers.put(array[1], intValue);
                    ArenaManager.getManager().getArena(array[1]).setMinPlayers(intValue);
                    commandSender.sendMessage(ChatColor.AQUA + "Successfully set the min players to " + array[2] + "!");
                }
                else {
                    commandSender.sendMessage(ChatColor.RED + "Proper usage of the command goes like this: /snake setminplayers <arena name> <int>");
                }
            }
            else {
                commandSender.sendMessage(ChatColor.RED + "You do not have permission to do that!");
            }
            return true;
        }
        if ((array[0].equalsIgnoreCase("leave") && commandSender instanceof Player) || (array[0].equalsIgnoreCase("depart") && commandSender instanceof Player)) {
            if (ArenaManager.getManager().isInGame((Player)commandSender)) {
                ArenaManager.getManager().removePlayer((Player)commandSender, false);
                commandSender.sendMessage(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.playerLeaveArenaMessage));
            }
            else {
                commandSender.sendMessage(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.playerLeaveNotInArena));
            }
            return true;
        }
        if (array[0].equalsIgnoreCase("create")) {
            if ((array.length == 2 && commandSender.hasPermission("supersnake.arenacreation")) || (array.length == 2 && commandSender.isOp())) {
                ArenaManager.getManager().createArena(((Player)commandSender).getLocation(), array[1], (Player)commandSender);
                commandSender.sendMessage("Created arena at " + ((Player)commandSender).getLocation().toString());
            }
            else {
                commandSender.sendMessage(ChatColor.RED + "Insufficiant Arguments! Proper use of the command goes like this: /ss create <arena name>");
            }
            return true;
        }
        if ((array[0].equalsIgnoreCase("arenas") && commandSender.hasPermission("supersnake.arenacreation")) || (array[0].equalsIgnoreCase("arenas") && commandSender.isOp())) {
            commandSender.sendMessage(new StringBuilder().append(ChatColor.AQUA).append(ChatColor.BOLD).append("There are ").append(String.valueOf(ArenaManager.getManager().getAllArenas().size())).append(" arena(s) on this server").toString());
            return true;
        }
        if (array[0].equalsIgnoreCase("stop") || array[0].equalsIgnoreCase("stoparena")) {
            if ((array.length == 2 && commandSender.hasPermission("supersnake.arenacreation")) || (array.length == 2 && commandSender.isOp())) {
                if (ArenaManager.getManager().getArena(array[1]) == null) {
                    commandSender.sendMessage(ChatColor.RED + "That arena doesn't exist!");
                    return true;
                }
                if (ArenaManager.getManager().getArena(array[1]).getPlayers().size() < 1) {
                    return true;
                }
                ArenaManager.getManager().stopArena(array[1], (Player)commandSender);
                commandSender.sendMessage(ChatColor.AQUA + "Arena Stopped");
                commandSender.sendMessage(ChatColor.RED + "Arena is not in game!");
            }
            else {
                commandSender.sendMessage(ChatColor.RED + "Insufficiant Arguments! Proper use of the command goes like this: /ss stop <arena name>");
            }
            return true;
        }
        if (array[0].equalsIgnoreCase("setboundslow") && commandSender instanceof Player) {
            if ((array.length == 2 && commandSender.hasPermission("supersnake.arenacreation")) || (array.length == 2 && commandSender.isOp())) {
                if (ArenaManager.getManager().getArena(array[1]) == null) {
                    commandSender.sendMessage(ChatColor.RED + "Captain, it is illogical to set the parameters of something that doesn't exist!");
                    return true;
                }
                if (ArenaManager.getManager().getArena(array[1]).getPlayers().size() > 0) {
                    commandSender.sendMessage(ChatColor.RED + "That arena has players in it. Please stop the game before performing this operation.");
                    return true;
                }
                ArenaManager.getManager().setBoundsLow(((Player)commandSender).getLocation(), array[1]);
                commandSender.sendMessage(ChatColor.AQUA + "Successfully set lower bound!");
            }
            else {
                commandSender.sendMessage(ChatColor.RED + "Insufficiant Arguments. Proper use of the command goes like this: /ss setboundslow <arena name>");
            }
            return true;
        }
        if (array[0].equalsIgnoreCase("start") || array[0].equalsIgnoreCase("startarena")) {
            if ((array.length == 2 && commandSender.hasPermission("supersnake.arenacreation")) || (array.length == 2 && commandSender.isOp())) {
                if (ArenaManager.getManager().getArena(array[1]) == null) {
                    commandSender.sendMessage(ChatColor.RED + "That arena doesn't exist!");
                    return true;
                }
                if (ArenaManager.getManager().getArena(array[1]).getPlayers().size() < 1) {
                    commandSender.sendMessage(ChatColor.RED + "You can't start an arena with no players in it!");
                    return true;
                }
                ArenaManager.getManager().startArena(array[1]);
                commandSender.sendMessage(ChatColor.AQUA + "You have force-started this arena");
            }
            else {
                commandSender.sendMessage(ChatColor.RED + "Insufficiant Arguments. Proper use of the command goes like this: /ss start <arena name>");
            }
            return true;
        }
        if (array[0].equalsIgnoreCase("setmainlobby") && commandSender instanceof Player) {
            if ((array.length == 2 && commandSender.hasPermission("supersnake.arenacreation")) || (array.length == 2 && commandSender.isOp())) {
                if (ArenaManager.getManager().getArena(array[1]) == null) {
                    commandSender.sendMessage(ChatColor.RED + "Captain, it is illogical to set the parameters of something that doesn't exist!");
                    return true;
                }
                if (ArenaManager.getManager().getArena(array[1]).getPlayers().size() > 0) {
                    commandSender.sendMessage(ChatColor.RED + "That arena has players in it. Please stop the game before performing this operation.");
                    return true;
                }
                ArenaManager.getManager().setMainLobby(((Player)commandSender).getLocation(), array[1]);
                commandSender.sendMessage(ChatColor.AQUA + "Successfully set main lobby!");
            }
            else {
                commandSender.sendMessage(ChatColor.RED + "Insufficiant Arguments. Proper use of the command goes like this: /ss setmainlobby <arena name>");
            }
            return true;
        }
        if (array[0].equalsIgnoreCase("setboundshigh") && commandSender instanceof Player) {
            if ((array.length == 2 && commandSender.hasPermission("supersnake.arenacreation")) || (array.length == 2 && commandSender.isOp())) {
                if (ArenaManager.getManager().getArena(array[1]) == null) {
                    commandSender.sendMessage(ChatColor.RED + "Captain, it is illogical to set the parameters of something that doesn't exist!");
                    return true;
                }
                if (ArenaManager.getManager().getArena(array[1]).getPlayers().size() > 0) {
                    commandSender.sendMessage(ChatColor.RED + "That arena has players in it. Please stop the game before performing this operation.");
                    return true;
                }
                if (ArenaManager.getManager().getArena(array[1]).getBoundsLow() == null) {
                    ArenaManager.getManager().setBoundsLow(((Player)commandSender).getLocation(), array[1]);
                }
                ArenaManager.getManager().setBoundsHigh(((Player)commandSender).getLocation(), array[1]);
                commandSender.sendMessage(ChatColor.AQUA + "Successfully set higher bound!");
            }
            else {
                commandSender.sendMessage(ChatColor.RED + "Insufficiant Arguments. Proper use of the command goes like this: /ss setboundshigh <arena name>");
            }
            return true;
        }
        if (array[0].equalsIgnoreCase("null")) {
            return true;
        }
        if (array[0].equalsIgnoreCase("setlobby") && commandSender instanceof Player) {
            if ((array.length == 2 && commandSender.hasPermission("supersnake.arenacreation")) || (array.length == 2 && commandSender.isOp())) {
                if (ArenaManager.getManager().getArena(array[1]) == null) {
                    commandSender.sendMessage(ChatColor.RED + "Captain, it is illogical to set the parameters of something that doesn't exist!");
                    return true;
                }
                if (ArenaManager.getManager().getArena(array[1]).getPlayers().size() > 0) {
                    commandSender.sendMessage(ChatColor.RED + "That arena has players in it. Please stop the game before performing this operation.");
                    return true;
                }
                ArenaManager.getManager().setArenaLobby(((Player)commandSender).getLocation(), array[1]);
                commandSender.sendMessage(ChatColor.AQUA + "Successfully set arena lobby!");
            }
            else {
                commandSender.sendMessage(ChatColor.RED + "Insufficiant Arguments. Proper use of the command goes like this: /ss setlobby <arena name>");
            }
            return true;
        }
        if (array[0].equalsIgnoreCase("addspawn") && commandSender instanceof Player) {
            if ((array.length == 2 && commandSender.hasPermission("supersnake.arenacreation")) || (array.length == 2 && commandSender.isOp())) {
                if (ArenaManager.getManager().getArena(array[1]) == null) {
                    commandSender.sendMessage(ChatColor.RED + "Captain, it is illogical to set the parameters of something that doesn't exist!");
                    return true;
                }
                if (ArenaManager.getManager().getArena(array[1]).getPlayers().size() > 0) {
                    commandSender.sendMessage(ChatColor.RED + "That arena has players in it. Please stop the game before performing this operation.");
                    return true;
                }
                ArenaManager.getManager().addSpawn(((Player)commandSender).getLocation(), array[1]);
                commandSender.sendMessage(ChatColor.AQUA + "You have added a new spawn point at your location!");
            }
            else {
                commandSender.sendMessage(ChatColor.RED + "Insufficiant Arguments. Proper use of the command goes like this: /ss addspawn <arena name>");
            }
            return true;
        }
        return false;
    }
}
