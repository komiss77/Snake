// 
// Decompiled by Procyon v0.5.30
// 

package com.dumbninja22.supersnake.ninjagamesAPI;

import java.sql.DriverManager;
import java.sql.Connection;
import org.bukkit.plugin.Plugin;

public class MySQL extends Database
{
    private final String user;
    private final String database;
    private final String password;
    private final int port;
    private final String hostname;
    
    public MySQL(final Plugin plugin, final String hostname, final int port, final String database, final String user, final String password) {
        super(plugin);
        this.hostname = hostname;
        this.port = port;
        this.database = database;
        this.user = user;
        this.password = password;
    }
    
    @Override
    public Connection openConnection() {
        if (this.checkConnection()) {
            return this.connection;
        }
        Class.forName("com.mysql.jdbc.Driver");
        return this.connection = DriverManager.getConnection("jdbc:mysql://" + this.hostname + ":" + this.port + "/" + this.database, this.user, this.password);
    }
}
