// 
// Decompiled by Procyon v0.5.30
// 

package com.dumbninja22.supersnake.ninjagamesAPI;

import org.bukkit.scoreboard.Score;
import org.bukkit.plugin.Plugin;
import java.util.Iterator;
import java.util.Map;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.OfflinePlayer;
import com.dumbninja22.supersnake.Main;
import java.util.List;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.ChatColor;
import org.bukkit.Bukkit;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.entity.Player;
import java.util.HashMap;
import org.bukkit.scoreboard.ScoreboardManager;
import com.dumbninja22.supersnake.Minigame;

public class IScoreboardManager
{
    private Minigame mg;
    private ScoreboardManager manager;
    private final HashMap<Player, SimpleScoreboard> sss;
    Scoreboard sb;
    Objective o;
    String former;
    
    public IScoreboardManager(final Minigame mg) {
        this.mg = null;
        this.manager = Bukkit.getScoreboardManager();
        this.sss = new HashMap<Player, SimpleScoreboard>();
        this.sb = null;
        this.o = null;
        this.former = null;
        this.mg = mg;
        if (mg.hasStarted()) {
            this.startScoreboard();
        }
        else {
            this.startPregameScoreboard();
        }
    }
    
    public void addPlayer(final Player player) {
        if (this.mg.hasStarted()) {
            player.setScoreboard(this.manager.getNewScoreboard());
            player.getScoreboard().registerNewObjective("snakeboard", "dummy");
            this.o.setDisplayName(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.scoreboardTitle));
            player.getScoreboard().getObjective("snakeboard").setDisplaySlot(DisplaySlot.SIDEBAR);
        }
        else {
            final SimpleScoreboard simpleScoreboard = new SimpleScoreboard(Messages.scoreboardTitle);
            if (this.mg.getOfficialArena().getState() == GameState.WAITING) {
                simpleScoreboard.add("Waiting...", 6);
                this.former = "Waiting...";
            }
            else {
                int numberII = this.mg.getOfficialArena().numberII;
                if (numberII == -250) {
                    numberII = 0;
                }
                simpleScoreboard.add(ChatColor.GOLD + "Starting in " + numberII, 6);
                this.former = ChatColor.GOLD + "Starting in " + numberII;
            }
            simpleScoreboard.add(" ", 5);
            if (ShopManager.owned.containsKey(player.getUniqueId())) {
                simpleScoreboard.add(ChatColor.AQUA + "Kits: " + ShopManager.owned.get(player.getUniqueId()).size(), 4);
            }
            else {
                simpleScoreboard.add(ChatColor.AQUA + "Kits: 0", 4);
            }
            simpleScoreboard.add("  ", 3);
            simpleScoreboard.add(ChatColor.GOLD + "Color: " + Main.nmsAccess.numToEc(this.mg.hashmapAlpha.get(player)).replace("_", " ").toUpperCase(), 2);
            simpleScoreboard.add("   ", 1);
            simpleScoreboard.add(ChatColor.GREEN + "Players: " + this.mg.hashmapAlpha.size(), 0);
            simpleScoreboard.update();
            simpleScoreboard.send(player);
            this.sss.put(player, simpleScoreboard);
        }
    }
    
    public void removePlayer(final Player player) {
        if (this.sss.containsKey(player)) {
            this.sss.get(player).reset();
            this.sss.remove(player);
        }
        if (this.sb != null && this.sb.getPlayers().contains(player)) {
            this.sb.resetScores((OfflinePlayer)player);
        }
        player.setScoreboard(Bukkit.getScoreboardManager().getNewScoreboard());
    }
    
    private void startPregameScoreboard() {
        final Iterator<Player> iterator = this.mg.hashmapAlpha.keySet().iterator();
        while (iterator.hasNext()) {
            this.addPlayer(iterator.next());
        }
        new BukkitRunnable() {
            public void run() {
                if (IScoreboardManager.this.mg == null || IScoreboardManager.this.sss == null || IScoreboardManager.this.sss.size() == 0) {
                    this.cancel();
                    return;
                }
                if (IScoreboardManager.this.mg.hasStarted()) {
                    this.cancel();
                    final Iterator<Map.Entry<K, SimpleScoreboard>> iterator = IScoreboardManager.this.sss.entrySet().iterator();
                    while (iterator.hasNext()) {
                        iterator.next().getValue().reset();
                    }
                    IScoreboardManager.this.sss.clear();
                    IScoreboardManager.this.startScoreboard();
                    return;
                }
                for (final Player player : IScoreboardManager.this.sss.keySet()) {
                    final SimpleScoreboard simpleScoreboard = IScoreboardManager.this.sss.get(player);
                    if (IScoreboardManager.this.mg.getOfficialArena().getState() == GameState.WAITING) {
                        simpleScoreboard.remove(6, IScoreboardManager.this.former);
                        simpleScoreboard.add("Waiting...", 6);
                        IScoreboardManager.this.former = "Waiting...";
                    }
                    else {
                        simpleScoreboard.remove(6, IScoreboardManager.this.former);
                        int numberII = IScoreboardManager.this.mg.getOfficialArena().numberII;
                        if (numberII == -250) {
                            numberII = 0;
                        }
                        simpleScoreboard.add(ChatColor.GOLD + "Starting in " + numberII, 6);
                        IScoreboardManager.this.former = ChatColor.GOLD + "Starting in " + numberII;
                    }
                    if (ShopManager.owned.containsKey(player.getUniqueId())) {
                        simpleScoreboard.add(ChatColor.AQUA + "Kits: " + ShopManager.owned.get(player.getUniqueId()).size(), 4);
                    }
                    else {
                        simpleScoreboard.add(ChatColor.AQUA + "Kits: 0", 4);
                    }
                    simpleScoreboard.add(ChatColor.GOLD + "Color: " + Main.nmsAccess.numToEc(IScoreboardManager.this.mg.hashmapAlpha.get(player)).replace("_", " ").toUpperCase(), 2);
                    simpleScoreboard.add(ChatColor.GREEN + "Players: " + IScoreboardManager.this.mg.hashmapAlpha.size(), 0);
                    simpleScoreboard.update();
                    simpleScoreboard.send(player);
                }
            }
        }.runTaskTimer((Plugin)Main.getPlugin((Class)Main.class), 0L, 10L);
    }
    
    public void updateScoreboard(final Player player, Player player2) {
        try {
            if (player == null) {
                return;
            }
            if (player2 == null) {
                player2 = player;
            }
            if (player.getUniqueId() != player2.getUniqueId() && player2 != null) {
                final Score score = this.o.getScore(Bukkit.getOfflinePlayer(player2.getDisplayName()));
                score.setScore(score.getScore() + 1);
            }
        }
        catch (Exception ex) {}
    }
    
    private void startScoreboard() {
        this.sb = this.manager.getNewScoreboard();
        (this.o = this.sb.registerNewObjective("snakeboard", "dummy")).setDisplayName(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.scoreboardTitle));
        this.o.setDisplaySlot(DisplaySlot.SIDEBAR);
        final Iterator<Player> iterator = this.mg.hashmapAlpha.keySet().iterator();
        while (iterator.hasNext()) {
            this.o.getScore(Bukkit.getOfflinePlayer(iterator.next().getDisplayName())).setScore(0);
        }
        final Iterator<Player> iterator2 = this.mg.hashmapAlpha.keySet().iterator();
        while (iterator2.hasNext()) {
            iterator2.next().setScoreboard(this.sb);
        }
    }
}
