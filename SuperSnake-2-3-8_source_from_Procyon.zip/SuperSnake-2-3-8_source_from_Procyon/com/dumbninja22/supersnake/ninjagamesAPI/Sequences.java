// 
// Decompiled by Procyon v0.5.30
// 

package com.dumbninja22.supersnake.ninjagamesAPI;

public class Sequences
{
    public static void startupSequence() {
        MySQLManager.loadFile();
        GUIManager.registerManager();
        ArenaManager.getManager().registerListener();
        SignManager.registerListener();
        EconomyManager.setupEconomy();
        ShopManager.startup();
        Messages.loadAll();
    }
    
    public static void shutdownSequence() {
        ShopManager.disable();
        FileManager.saveAll();
    }
}
