// 
// Decompiled by Procyon v0.5.30
// 

package com.dumbninja22.supersnake.ninjagamesAPI;

import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.event.EventPriority;
import org.bukkit.event.EventHandler;
import org.bukkit.ChatColor;
import org.bukkit.event.player.PlayerMoveEvent;
import java.util.Iterator;
import org.bukkit.plugin.Plugin;
import com.dumbninja22.supersnake.Main;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.entity.Player;
import java.util.ArrayList;
import com.dumbninja22.supersnake.Minigame;
import java.util.UUID;
import org.bukkit.Location;
import java.util.List;
import org.bukkit.event.Listener;

public class Arena implements Listener
{
    private String id;
    private List<Location> spawns;
    private List<UUID> players;
    private Location boundsLow;
    private Location boundsHigh;
    private Location arenaLobby;
    private Location mainLobby;
    private Minigame iArena;
    private String serverid;
    private ArrayList<Player> frozenPlayers;
    private GameState state;
    private int minPlayers;
    public int maxplayers;
    int numberII;
    BukkitTask taskII;
    int number;
    int task;
    int freezeWalk;
    
    public Arena(final List<Location> spawns, final String id, final Minigame iArena, final Location arenaLobby, final Location mainLobby, final Location boundsLow, final Location boundsHigh, final String serverid) {
        this.spawns = new ArrayList<Location>();
        this.players = new ArrayList<UUID>();
        this.frozenPlayers = new ArrayList<Player>();
        this.state = GameState.WAITING;
        this.minPlayers = 2;
        this.maxplayers = 1;
        this.numberII = -250;
        this.number = -250;
        this.freezeWalk = 0;
        final Iterator<Arena> iterator = ArenaManager.getManager().getAllArenas().iterator();
        while (iterator.hasNext()) {
            if (iterator.next().getId().equals(id)) {
                return;
            }
        }
        this.spawns = spawns;
        try {
            this.arenaLobby = arenaLobby;
            this.mainLobby = mainLobby;
            this.boundsLow = boundsLow;
            this.boundsHigh = boundsHigh;
            this.maxplayers = spawns.size();
            this.serverid = serverid;
        }
        catch (NullPointerException ex) {}
        this.id = id;
        this.iArena = iArena;
        Bukkit.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)Main.getPlugin((Class)Main.class));
    }
    
    @EventHandler(priority = EventPriority.HIGH)
    public void onWalk(final PlayerMoveEvent playerMoveEvent) {
        final Player player = playerMoveEvent.getPlayer();
        if (!this.players.contains(player.getUniqueId())) {
            return;
        }
        if (this.players.contains(player.getUniqueId())) {
            double doubleValue;
            try {
                doubleValue = (double)player.getClass().getMethod("getMaxHealth", (Class<?>[])new Class[0]).invoke(player, new Object[0]);
            }
            catch (Exception ex) {
                try {
                    doubleValue = (int)player.getClass().getMethod("getMaxHealth", (Class<?>[])new Class[0]).invoke(player, new Object[0]);
                }
                catch (Exception ex2) {
                    doubleValue = 20.0;
                }
            }
            player.setHealth(doubleValue);
            player.setFoodLevel(20);
            return;
        }
        if (this.getState() == GameState.STARTED && this.getPlayers().contains(player.getUniqueId()) && !ArenaManager.isInside(playerMoveEvent.getTo(), this.getBoundsLow().toVector(), this.getBoundsHigh().toVector())) {
            playerMoveEvent.setCancelled(true);
            player.sendMessage(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.playerLeaveBoundsMessage));
            player.setVelocity(player.getLocation().toVector().subtract(playerMoveEvent.getTo().toVector().normalize()).multiply(0.05));
        }
    }
    
    public String getId() {
        return this.id;
    }
    
    public void removeFromFrozenPlayers(final Player player) {
        this.frozenPlayers.remove(player);
    }
    
    public String getServerId() {
        return this.serverid;
    }
    
    public JavaPlugin getPlugin() {
        return Main.getPlugin((Class)Main.class);
    }
    
    public List<UUID> getPlayers() {
        return this.players;
    }
    
    public void removePlayerFromList(final UUID uuid) {
        this.players.remove(uuid);
    }
    
    public List<Location> getSpawns() {
        return this.spawns;
    }
    
    public Location getBoundsLow() {
        return this.boundsLow;
    }
    
    public Location getBoundsHigh() {
        return this.boundsHigh;
    }
    
    public Location getArenaLobby() {
        return this.arenaLobby;
    }
    
    public Location getMainLobby() {
        return this.mainLobby;
    }
    
    public GameState getState() {
        return this.state;
    }
    
    public Minigame getIArena() {
        return this.iArena;
    }
    
    public int getMinPlayers() {
        return this.minPlayers;
    }
    
    public void setBoundsLow(final Location boundsLow) {
        this.boundsLow = boundsLow;
    }
    
    public void clearFrozenPlayers() {
        this.frozenPlayers.clear();
    }
    
    public void setServerId(final String serverid) {
        this.serverid = serverid;
    }
    
    public void setBoundsHigh(final Location boundsHigh) {
        this.boundsHigh = boundsHigh;
    }
    
    public void setArenaLobby(final Location arenaLobby) {
        this.arenaLobby = arenaLobby;
    }
    
    public void setMainLobby(final Location mainLobby) {
        this.mainLobby = mainLobby;
    }
    
    public void setMinPlayers(final Integer n) {
        this.minPlayers = n;
    }
    
    public void setState(final GameState state) {
        this.state = state;
    }
    
    public void setIArena(final Minigame iArena) {
        if (this.iArena != null) {
            System.gc();
        }
        this.iArena = iArena;
    }
    
    public void startCountdownII() {
        final Iterator<UUID> iterator = this.getPlayers().iterator();
        while (iterator.hasNext()) {
            Utils.getPlayerByUUID(iterator.next()).sendMessage(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.arenaStartingMessage.replace("[X]", String.valueOf(this.numberII))));
        }
        this.taskII = new BukkitRunnable() {
            public void run() {
                if (Arena.this.numberII > -1 && Arena.this.numberII != -250) {
                    if (Arena.this.numberII != 0) {
                        final Arena this$0 = Arena.this;
                        --this$0.numberII;
                        final Iterator<UUID> iterator = Arena.this.getPlayers().iterator();
                        while (iterator.hasNext()) {
                            final Player playerByUUID = Utils.getPlayerByUUID(iterator.next());
                            if (Arena.this.numberII >= 0) {
                                playerByUUID.setLevel(Arena.this.numberII);
                            }
                            if (Arena.this.numberII <= 3 && Arena.this.numberII > 0) {
                                playerByUUID.sendMessage(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.arenaStartingMessage.replace("[X]", String.valueOf(Arena.this.numberII))));
                            }
                        }
                    }
                    else {
                        Arena.this.numberII = -250;
                        this.cancel();
                        Arena.this.setState(GameState.INGAME);
                        ArenaManager.getManager().startArena(Arena.this.getId());
                    }
                }
                else {
                    this.cancel();
                }
            }
        }.runTaskTimer((Plugin)Main.getPlugin((Class)Main.class), 0L, 20L);
    }
    
    public void initiateStart() {
        this.preStart();
    }
    
    public void addSpawn(final Location location) {
        this.spawns.add(location);
        this.maxplayers = this.spawns.size();
    }
    
    public void startCountdown() {
        if (Bukkit.getServer().getScheduler().isCurrentlyRunning(this.task)) {
            return;
        }
        this.setState(GameState.STARTING);
        this.task = ((Main)Main.getPlugin((Class)Main.class)).getServer().getScheduler().scheduleSyncRepeatingTask((Plugin)Main.getPlugin((Class)Main.class), (Runnable)new Runnable() {
            @Override
            public void run() {
                if (Arena.this.number > -1 && Arena.this.number != -250) {
                    if (Arena.this.number != 0) {
                        if (Arena.this.number == 10 || Arena.this.number <= 5) {
                            final Iterator<UUID> iterator = (Iterator<UUID>)Arena.this.players.iterator();
                            while (iterator.hasNext()) {
                                Utils.getPlayerByUUID(iterator.next()).sendMessage(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.gameStartingIn.replace("[X]", String.valueOf(Arena.this.number))));
                            }
                        }
                        final Arena this$0 = Arena.this;
                        --this$0.number;
                    }
                    else {
                        Arena.this.number = -250;
                        Bukkit.getServer().getScheduler().cancelTask(Arena.this.task);
                        Arena.this.freezeWalk = 0;
                        Arena.this.iArena.started();
                        Arena.this.setState(GameState.STARTED);
                        final Iterator<UUID> iterator2 = (Iterator<UUID>)Arena.this.players.iterator();
                        while (iterator2.hasNext()) {
                            final Player playerByUUID = Utils.getPlayerByUUID(iterator2.next());
                            playerByUUID.setLevel(0);
                            playerByUUID.sendMessage(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.goMessage));
                        }
                        Arena.this.clearFrozenPlayers();
                    }
                }
                else {
                    Bukkit.getServer().getScheduler().cancelTask(Arena.this.task);
                }
            }
        }, 0L, 20L);
    }
    
    public void preStart() {
        this.freezeWalk = 1;
        final Iterator<UUID> iterator = this.players.iterator();
        while (iterator.hasNext()) {
            Utils.getPlayerByUUID(iterator.next()).sendMessage(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.gameStartingPleaseWaitMessage));
        }
        Bukkit.getServer().getScheduler().scheduleSyncDelayedTask((Plugin)Main.getPlugin((Class)Main.class), (Runnable)new Runnable() {
            @Override
            public void run() {
                Arena.this.start();
            }
        }, 80L);
    }
    
    public void start() {
        int n = 0;
        final int size = this.players.size();
        this.number = 10;
        this.freezeWalk = 0;
        this.startCountdown();
        final Iterator<UUID> iterator = this.players.iterator();
        while (iterator.hasNext()) {
            final Player playerByUUID = Utils.getPlayerByUUID(iterator.next());
            if (n < size) {
                playerByUUID.teleport((Location)this.spawns.get(n));
                this.frozenPlayers.add(playerByUUID);
                ++n;
            }
        }
        this.iArena.start(true);
    }
}
