// 
// Decompiled by Procyon v0.5.30
// 

package com.dumbninja22.supersnake.ninjagamesAPI;

import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import java.util.Map;
import java.util.Iterator;
import java.io.IOException;
import org.bukkit.configuration.file.YamlConfiguration;
import com.dumbninja22.supersnake.Main;
import org.bukkit.configuration.file.FileConfiguration;
import java.io.File;
import org.bukkit.plugin.Plugin;
import java.util.List;
import java.util.UUID;
import java.util.HashMap;
import net.milkbowl.vault.economy.Economy;

public class ShopManager
{
    static Economy economy;
    static HashMap<UUID, Boolean> colorChooser;
    public static HashMap<UUID, List<String>> owned;
    public static HashMap<UUID, String> selected;
    static Plugin plugin;
    static File customYml;
    static FileConfiguration customConfig;
    
    static {
        ShopManager.economy = null;
        ShopManager.colorChooser = new HashMap<UUID, Boolean>();
        ShopManager.owned = new HashMap<UUID, List<String>>();
        ShopManager.selected = new HashMap<UUID, String>();
        ShopManager.plugin = (Plugin)Main.getPlugin((Class)Main.class);
        ShopManager.customYml = new File(ShopManager.plugin.getDataFolder() + "/shopdata.yml");
        ShopManager.customConfig = (FileConfiguration)YamlConfiguration.loadConfiguration(ShopManager.customYml);
    }
    
    private static void saveCustomYml(final FileConfiguration fileConfiguration, final File file) {
        try {
            fileConfiguration.save(file);
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    public static void startup() {
        try {
            final HashMap<UUID, Boolean> colorChooser = new HashMap<UUID, Boolean>();
            for (final String s : ShopManager.customConfig.getConfigurationSection("colorChooser").getKeys(false)) {
                colorChooser.put(UUID.fromString(s), ShopManager.customConfig.getBoolean("colorChooser." + s));
            }
            if (colorChooser != null || colorChooser.size() > 0) {
                ShopManager.colorChooser = colorChooser;
            }
        }
        catch (NullPointerException ex) {}
        try {
            final HashMap<UUID, List<String>> owned = new HashMap<UUID, List<String>>();
            for (final String s2 : ShopManager.customConfig.getConfigurationSection("speedboosts").getKeys(false)) {
                owned.put(UUID.fromString(s2), ShopManager.customConfig.getList("speedboosts." + s2));
            }
            if (owned != null || owned.size() > 0) {
                ShopManager.owned = owned;
            }
        }
        catch (NullPointerException ex2) {}
        ShopManager.economy = EconomyManager.economy;
    }
    
    public static boolean findPlayerInOwned(final UUID uuid, final String s) {
        for (final Map.Entry<UUID, List<String>> entry : ShopManager.owned.entrySet()) {
            if (entry.getKey().toString().equals(uuid.toString())) {
                final Iterator<String> iterator2 = entry.getValue().iterator();
                while (iterator2.hasNext()) {
                    if (iterator2.next().contains(s)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    public static boolean findPlayerInColorChooser(final UUID uuid) {
        for (final Map.Entry<UUID, Boolean> entry : ShopManager.colorChooser.entrySet()) {
            if (entry.getKey().equals(uuid) && entry.getValue()) {
                return true;
            }
        }
        return false;
    }
    
    public static void disable() {
        for (final Map.Entry<UUID, Boolean> entry : ShopManager.colorChooser.entrySet()) {
            ShopManager.customConfig.set("colorChooser." + entry.getKey(), (Object)entry.getValue());
        }
        for (final Map.Entry<UUID, List<String>> entry2 : ShopManager.owned.entrySet()) {
            ShopManager.customConfig.set("speedboosts." + entry2.getKey(), (Object)entry2.getValue());
        }
        saveCustomYml(ShopManager.customConfig, ShopManager.customYml);
    }
    
    public boolean purchaseColorChooser(final Player player) {
        if (ShopManager.economy == null) {
            return false;
        }
        if (ShopManager.economy.getBalance((OfflinePlayer)player) < FileManager.priceColorChooser) {
            return false;
        }
        if (ShopManager.economy.withdrawPlayer((OfflinePlayer)player, (double)FileManager.priceColorChooser).transactionSuccess()) {
            ShopManager.colorChooser.put(player.getUniqueId(), true);
            return true;
        }
        return false;
    }
    
    public boolean doesHaveColorChooser(final Player player) {
        return ShopManager.colorChooser.containsKey(player.getUniqueId());
    }
}
