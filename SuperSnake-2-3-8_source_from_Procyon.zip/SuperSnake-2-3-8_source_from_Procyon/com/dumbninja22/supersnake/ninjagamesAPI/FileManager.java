// 
// Decompiled by Procyon v0.5.30
// 

package com.dumbninja22.supersnake.ninjagamesAPI;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.Location;
import java.util.Map;
import java.util.Iterator;
import java.util.Collection;
import java.util.Arrays;
import java.util.ArrayList;
import org.bukkit.configuration.file.YamlConfiguration;
import com.dumbninja22.supersnake.Main;
import java.util.List;
import java.util.HashMap;
import org.bukkit.configuration.file.FileConfiguration;
import java.io.File;
import org.bukkit.plugin.Plugin;

public class FileManager
{
    static Plugin plugin;
    static File customYml;
    static FileConfiguration customConfig;
    public static int priceColorChooser;
    public static int creditOnWin;
    public static int creditOnHitSomeoneOut;
    public static int creditForParticipation;
    public static int speedboostTimeTicks;
    public static double snakeDefaultSpeed;
    public static double snakeBoostedSpeed;
    public static double snakeSugerBoostedSpeed;
    public static int chanceOfSugerSpawning;
    public static int maxSugarOnGround;
    public static boolean allowHostileMobSpawningInArena;
    public static int fastSnakePrice;
    public static int ferrariSnakePrice;
    public static int ferrariKitBoosts;
    public static int fastKitBoosts;
    public static String winMessage;
    public static String eliminatePlayerMessage;
    public static String joinArenaMessage;
    public static boolean bungee;
    public static final HashMap<String, Integer> minPlayers;
    public static final List<String> allowedcmds;
    
    static {
        FileManager.plugin = (Plugin)Main.getPlugin((Class)Main.class);
        FileManager.customYml = new File(FileManager.plugin.getDataFolder() + "/SSarenas.yml");
        FileManager.customConfig = (FileConfiguration)YamlConfiguration.loadConfiguration(FileManager.customYml);
        FileManager.priceColorChooser = 450;
        FileManager.creditOnWin = 30;
        FileManager.creditOnHitSomeoneOut = 5;
        FileManager.creditForParticipation = 2;
        FileManager.speedboostTimeTicks = 70;
        FileManager.snakeDefaultSpeed = 0.45;
        FileManager.snakeBoostedSpeed = 0.65;
        FileManager.snakeSugerBoostedSpeed = 0.55;
        FileManager.chanceOfSugerSpawning = 5;
        FileManager.maxSugarOnGround = 7;
        FileManager.fastSnakePrice = 200;
        FileManager.ferrariSnakePrice = 600;
        FileManager.ferrariKitBoosts = 10;
        FileManager.fastKitBoosts = 5;
        FileManager.bungee = false;
        minPlayers = new HashMap<String, Integer>();
        allowedcmds = new ArrayList<String>();
    }
    
    public static void loadBasic() {
        FileManager.plugin.getConfig().addDefault("creditOnWin", (Object)30);
        FileManager.plugin.getConfig().addDefault("priceColorChooser", (Object)450);
        FileManager.plugin.getConfig().addDefault("creditOnHitSomeoneOut", (Object)5);
        FileManager.plugin.getConfig().addDefault("creditForParticipation", (Object)2);
        FileManager.plugin.getConfig().addDefault("fastSnakePrice", (Object)200);
        FileManager.plugin.getConfig().addDefault("ferrariSnakePrice", (Object)600);
        FileManager.plugin.getConfig().addDefault("ferrariKitBoosts", (Object)10);
        FileManager.plugin.getConfig().addDefault("fastKitBoosts", (Object)5);
        FileManager.plugin.getConfig().addDefault("speedboostTimeTicks", (Object)70);
        FileManager.plugin.getConfig().addDefault("snakeDefaultSpeed", (Object)0.45);
        FileManager.plugin.getConfig().addDefault("snakeBoostedSpeed", (Object)0.65);
        FileManager.plugin.getConfig().addDefault("chanceOfSugerSpawning", (Object)5);
        FileManager.plugin.getConfig().addDefault("maxSugarOnGround", (Object)7);
        FileManager.plugin.getConfig().addDefault("snakeSugerBoostedSpeed", (Object)0.55);
        FileManager.plugin.getConfig().addDefault("bungeecord", (Object)false);
        FileManager.plugin.getConfig().addDefault("allowHostileMobSpawningInArena", (Object)false);
        FileManager.plugin.getConfig().addDefault("allowedcmds", (Object)new ArrayList(Arrays.asList("snake leave", "snake", "snake stop", "help")));
        FileManager.plugin.getConfig().options().copyDefaults(true);
        FileManager.plugin.saveConfig();
        FileManager.creditOnWin = FileManager.plugin.getConfig().getInt("creditOnWin");
        FileManager.priceColorChooser = FileManager.plugin.getConfig().getInt("priceColorChooser");
        FileManager.creditOnHitSomeoneOut = FileManager.plugin.getConfig().getInt("creditOnHitSomeoneOut");
        FileManager.creditForParticipation = FileManager.plugin.getConfig().getInt("creditForParticipation");
        FileManager.ferrariSnakePrice = FileManager.plugin.getConfig().getInt("ferrariSnakePrice");
        FileManager.fastSnakePrice = FileManager.plugin.getConfig().getInt("fastSnakePrice");
        FileManager.ferrariKitBoosts = FileManager.plugin.getConfig().getInt("ferrariKitBoosts");
        FileManager.fastKitBoosts = FileManager.plugin.getConfig().getInt("fastKitBoosts");
        FileManager.speedboostTimeTicks = FileManager.plugin.getConfig().getInt("speedboostTimeTicks");
        FileManager.snakeDefaultSpeed = FileManager.plugin.getConfig().getDouble("snakeDefaultSpeed");
        FileManager.snakeBoostedSpeed = FileManager.plugin.getConfig().getDouble("snakeBoostedSpeed");
        FileManager.chanceOfSugerSpawning = FileManager.plugin.getConfig().getInt("chanceOfSugerSpawning");
        FileManager.snakeSugerBoostedSpeed = FileManager.plugin.getConfig().getDouble("snakeSugerBoostedSpeed");
        FileManager.maxSugarOnGround = FileManager.plugin.getConfig().getInt("maxSugarOnGround");
        FileManager.bungee = FileManager.plugin.getConfig().getBoolean("bungeecord");
        FileManager.allowHostileMobSpawningInArena = FileManager.plugin.getConfig().getBoolean("allowHostileMobSpawningInArena");
        try {
            for (final String s : FileManager.plugin.getConfig().getConfigurationSection("minPlayers").getKeys(false)) {
                FileManager.minPlayers.put(s, FileManager.plugin.getConfig().getInt("minPlayers." + s));
            }
            final Iterator<String> iterator2 = FileManager.plugin.getConfig().getStringList("allowedcmds").iterator();
            while (iterator2.hasNext()) {
                FileManager.allowedcmds.add(iterator2.next());
            }
        }
        catch (Exception ex) {}
    }
    
    public static void loadAll() {
        try {
            loadBasic();
            final ConfigurationSection configurationSection = FileManager.customConfig.getConfigurationSection("SSArenas");
            final HashMap<String, List> hashMap = new HashMap<String, List>();
            for (final String s : configurationSection.getKeys(false)) {
                hashMap.put(s, configurationSection.getList(s));
                FileManager.plugin.getConfig().addDefault("minPlayers." + s, (Object)2);
            }
            FileManager.customConfig.options().copyDefaults(true);
            FileManager.plugin.getConfig().options().copyDefaults(true);
            FileManager.plugin.saveConfig();
            if (hashMap.size() > 0) {
                for (final Map.Entry<String, List> entry : hashMap.entrySet()) {
                    final ArrayList<Location> list = new ArrayList<Location>();
                    final Iterator<String> iterator3 = entry.getValue().iterator();
                    while (iterator3.hasNext()) {
                        list.add(Utils.stringToLoc(iterator3.next()));
                    }
                    final Arena massCreateArena = ArenaManager.getManager().massCreateArena(list, entry.getKey(), Utils.stringToLoc(FileManager.customConfig.getConfigurationSection("arenaLobby").getString((String)entry.getKey())), Utils.stringToLoc(FileManager.customConfig.getConfigurationSection("mainLobby").getString((String)entry.getKey())), Utils.stringToLoc(FileManager.customConfig.getConfigurationSection("boundsLow").getString((String)entry.getKey())), Utils.stringToLoc(FileManager.customConfig.getConfigurationSection("boundsHigh").getString((String)entry.getKey())), FileManager.plugin, "none");
                    if (FileManager.minPlayers.containsKey(massCreateArena.getId())) {
                        massCreateArena.setMinPlayers(FileManager.minPlayers.get(massCreateArena.getId()));
                    }
                    else {
                        massCreateArena.setMinPlayers(2);
                    }
                }
            }
        }
        catch (NullPointerException ex) {}
    }
    
    public static void saveAll() {
        if (MySQLManager.sqlEnabled) {
            MySQLManager.saveAll();
            return;
        }
        SignManager.savefile();
        for (final Arena arena : ArenaManager.getManager().getAllArenas()) {
            final Location boundsLow = arena.getBoundsLow();
            final Location boundsHigh = arena.getBoundsHigh();
            final Location arenaLobby = arena.getArenaLobby();
            FileManager.customConfig.set("mainLobby." + arena.getId(), (Object)Utils.locToString(arena.getMainLobby()));
            FileManager.customConfig.set("arenaLobby." + arena.getId(), (Object)Utils.locToString(arenaLobby));
            FileManager.customConfig.set("boundsLow." + arena.getId(), (Object)Utils.locToString(boundsLow));
            FileManager.customConfig.set("boundsHigh." + arena.getId(), (Object)Utils.locToString(boundsHigh));
            final ArrayList<String> list = new ArrayList<String>();
            final Iterator<Location> iterator2 = arena.getSpawns().iterator();
            while (iterator2.hasNext()) {
                list.add(Utils.locToString(iterator2.next()));
            }
            if (FileManager.minPlayers.containsKey(arena.getId())) {
                FileManager.plugin.getConfig().set("minPlayers." + arena.getId(), (Object)FileManager.minPlayers.get(arena.getId()));
            }
            else {
                FileManager.plugin.getConfig().set("minPlayers." + arena.getId(), (Object)2);
            }
            FileManager.customConfig.set("SSArenas." + arena.getId(), (Object)list);
        }
        FileManager.plugin.saveConfig();
        Utils.saveCustomYml(FileManager.customConfig, FileManager.customYml);
    }
}
