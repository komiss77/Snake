// 
// Decompiled by Procyon v0.5.30
// 

package com.dumbninja22.supersnake.ver;

import net.minecraft.server.v1_8_R2.WorldServer;
import net.minecraft.server.v1_8_R2.World;
import org.bukkit.craftbukkit.v1_8_R2.CraftWorld;
import net.minecraft.server.v1_8_R2.EntityTypes;
import java.util.Map;
import java.util.Iterator;
import java.lang.reflect.Field;
import java.util.List;
import net.minecraft.server.v1_8_R2.BiomeBase;
import net.minecraft.server.v1_8_R2.EntitySheep;
import org.bukkit.entity.EntityType;
import org.bukkit.craftbukkit.v1_8_R2.entity.CraftSheep;
import org.bukkit.plugin.Plugin;
import com.dumbninja22.supersnake.Main;
import net.minecraft.server.v1_8_R2.PathEntity;
import org.bukkit.Location;
import net.minecraft.server.v1_8_R2.GenericAttributes;
import org.bukkit.craftbukkit.v1_8_R2.entity.CraftEntity;
import net.minecraft.server.v1_8_R2.EntityInsentient;
import com.dumbninja22.supersnake.ninjagamesAPI.FileManager;
import com.dumbninja22.supersnake.ninjagamesAPI.ArenaManager;
import org.bukkit.scheduler.BukkitRunnable;
import com.dumbninja22.supersnake.Minigame;
import org.bukkit.entity.Entity;
import net.minecraft.server.v1_8_R2.EnumColor;
import net.minecraft.server.v1_8_R2.Packet;
import org.bukkit.craftbukkit.v1_8_R2.entity.CraftPlayer;
import net.minecraft.server.v1_8_R2.IChatBaseComponent;
import net.minecraft.server.v1_8_R2.PacketPlayOutTitle;
import org.bukkit.entity.Player;
import com.dumbninja22.supersnake.ninjagamesAPI.Utils;
import com.dumbninja22.supersnake.NMS;

public class v1_8_R2 implements NMS
{
    @Override
    public void registerEntities() {
        CustomEntityType.registerEntities();
        Utils.echo("We're on 1_8R2");
    }
    
    @Override
    public void showTitle(final String s, final Player player) {
        final PacketPlayOutTitle packetPlayOutTitle = new PacketPlayOutTitle(PacketPlayOutTitle.EnumTitleAction.TITLE, IChatBaseComponent.ChatSerializer.a(s));
        final PacketPlayOutTitle packetPlayOutTitle2 = new PacketPlayOutTitle(5, 40, 5);
        ((CraftPlayer)player).getHandle().playerConnection.sendPacket((Packet)packetPlayOutTitle);
        ((CraftPlayer)player).getHandle().playerConnection.sendPacket((Packet)packetPlayOutTitle2);
    }
    
    public EnumColor numToEcc(final int n) {
        if (n == 0) {
            return EnumColor.WHITE;
        }
        if (n == 1) {
            return EnumColor.ORANGE;
        }
        if (n == 2) {
            return EnumColor.MAGENTA;
        }
        if (n == 3) {
            return EnumColor.LIGHT_BLUE;
        }
        if (n == 4) {
            return EnumColor.YELLOW;
        }
        if (n == 5) {
            return EnumColor.LIME;
        }
        if (n == 6) {
            return EnumColor.PINK;
        }
        if (n == 7) {
            return EnumColor.GRAY;
        }
        if (n == 8) {
            return EnumColor.SILVER;
        }
        if (n == 9) {
            return EnumColor.CYAN;
        }
        if (n == 10) {
            return EnumColor.PURPLE;
        }
        if (n == 11) {
            return EnumColor.BLUE;
        }
        if (n == 12) {
            return EnumColor.BROWN;
        }
        if (n == 13) {
            return EnumColor.GREEN;
        }
        if (n == 14) {
            return EnumColor.RED;
        }
        if (n == 15) {
            return EnumColor.BLACK;
        }
        if (n > 15) {
            return EnumColor.WHITE;
        }
        return EnumColor.WHITE;
    }
    
    @Override
    public void pathfind(final Entity entity, final Entity entity2, final Player player, final Minigame minigame) {
        new BukkitRunnable() {
            public void run() {
                if (!minigame.hasStarted()) {
                    entity2.remove();
                    this.cancel();
                }
                if (!entity2.isValid()) {
                    this.cancel();
                }
                if (!ArenaManager.getManager().searchForPlayer(player)) {
                    this.cancel();
                }
                Double n = FileManager.snakeDefaultSpeed;
                if (minigame.playerHasSpeedBoost(player)) {
                    if (minigame.wasPlayerSugarBoosted(player)) {
                        n = FileManager.snakeSugerBoostedSpeed;
                    }
                    else {
                        n = FileManager.snakeBoostedSpeed;
                    }
                }
                final Double value = 60.0;
                0.0;
                0.0;
                Double n2 = n - Double.valueOf(n * (value / 100.0));
                if (n2 < 0.1) {
                    n2 = 0.2;
                }
                ((EntityInsentient)((CraftEntity)entity2).getHandle()).getNavigation().a(2.0f);
                final net.minecraft.server.v1_8_R2.Entity handle = ((CraftEntity)entity2).getHandle();
                final Location location = entity.getLocation();
                final PathEntity a = ((EntityInsentient)handle).getNavigation().a(location.getX(), location.getY(), location.getZ());
                if (a != null) {
                    ((EntityInsentient)handle).getNavigation().a(a, 1.0);
                    ((EntityInsentient)handle).getNavigation().a(2.0);
                }
                ((EntityInsentient)((CraftEntity)entity2).getHandle()).getAttributeInstance(GenericAttributes.b).setValue(999.0);
                entity2.getLocation().setDirection(entity.getLocation().getDirection());
                ((EntityInsentient)((CraftEntity)entity2).getHandle()).getAttributeInstance(GenericAttributes.d).setValue((double)n2);
            }
        }.runTaskTimer((Plugin)Main.getPlugin((Class)Main.class), 0L, 2L);
    }
    
    @Override
    public void changeDir(final Entity entity, final Player player) {
        ((CraftSheep)entity).getHandle().yaw = player.getLocation().getYaw();
    }
    
    @Override
    public Entity spawnX(final Location location, final Integer n, final Float n2) {
        return CustomEntityType.spawnX(location, this.numToEcc(n), n2);
    }
    
    @Override
    public String numToEc(final int n) {
        if (n == 0) {
            return EnumColor.WHITE.toString();
        }
        if (n == 1) {
            return EnumColor.ORANGE.toString();
        }
        if (n == 2) {
            return EnumColor.MAGENTA.toString();
        }
        if (n == 3) {
            return EnumColor.LIGHT_BLUE.toString();
        }
        if (n == 4) {
            return EnumColor.YELLOW.toString();
        }
        if (n == 5) {
            return EnumColor.LIME.toString();
        }
        if (n == 6) {
            return EnumColor.PINK.toString();
        }
        if (n == 7) {
            return EnumColor.GRAY.toString();
        }
        if (n == 8) {
            return EnumColor.SILVER.toString();
        }
        if (n == 9) {
            return EnumColor.CYAN.toString();
        }
        if (n == 10) {
            return EnumColor.PURPLE.toString();
        }
        if (n == 11) {
            return EnumColor.BLUE.toString();
        }
        if (n == 12) {
            return EnumColor.BROWN.toString();
        }
        if (n == 13) {
            return EnumColor.GREEN.toString();
        }
        if (n == 14) {
            return EnumColor.RED.toString();
        }
        if (n == 15) {
            return EnumColor.BLACK.toString();
        }
        if (n > 15) {
            return EnumColor.WHITE.toString();
        }
        return EnumColor.WHITE.toString();
    }
    
    public enum CustomEntityType
    {
        CUSTOMSHEEP("Sheep", 91, EntityType.SHEEP, (Class<? extends EntityInsentient>)EntitySheep.class, (Class<? extends EntityInsentient>)CustomSheep183.class);
        
        private String name;
        private int id;
        private EntityType entityType;
        private Class<? extends EntityInsentient> nmsClass;
        private Class<? extends EntityInsentient> customClass;
        
        private CustomEntityType(final String name, final int id, final EntityType entityType, final Class<? extends EntityInsentient> nmsClass, final Class<? extends EntityInsentient> customClass) {
            this.name = new String();
            this.name = name;
            this.id = id;
            this.entityType = entityType;
            this.nmsClass = nmsClass;
            this.customClass = customClass;
        }
        
        public String getName() {
            return this.name;
        }
        
        public int getID() {
            return this.id;
        }
        
        public EntityType getEntityType() {
            return this.entityType;
        }
        
        public Class<? extends EntityInsentient> getNMSClass() {
            return this.nmsClass;
        }
        
        public Class<? extends EntityInsentient> getCustomClass() {
            return this.customClass;
        }
        
        public static void registerEntities() {
            CustomEntityType[] values;
            for (int length = (values = values()).length, i = 0; i < length; ++i) {
                final CustomEntityType customEntityType = values[i];
                a(customEntityType.getCustomClass(), customEntityType.getName(), customEntityType.getID());
            }
            BiomeBase[] array;
            try {
                array = (BiomeBase[])getPrivateStatic(BiomeBase.class, "biomes");
            }
            catch (Exception ex2) {
                return;
            }
            BiomeBase[] array2;
            for (int length2 = (array2 = array).length, j = 0; j < length2; ++j) {
                final BiomeBase biomeBase = array2[j];
                if (biomeBase == null) {
                    break;
                }
                String[] array3;
                for (int length3 = (array3 = new String[] { "at", "au", "av", "aw" }).length, k = 0; k < length3; ++k) {
                    final String s = array3[k];
                    try {
                        final Field declaredField = BiomeBase.class.getDeclaredField(s);
                        declaredField.setAccessible(true);
                        for (final BiomeBase.BiomeMeta biomeMeta : (List)declaredField.get(biomeBase)) {
                            CustomEntityType[] values2;
                            for (int length4 = (values2 = values()).length, l = 0; l < length4; ++l) {
                                final CustomEntityType customEntityType2 = values2[l];
                                if (customEntityType2.getNMSClass().equals(biomeMeta.b)) {
                                    biomeMeta.b = customEntityType2.getCustomClass();
                                }
                            }
                        }
                    }
                    catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            }
        }
        
        public static void unregisterEntities() {
            CustomEntityType[] values;
            for (int length = (values = values()).length, i = 0; i < length; ++i) {
                final CustomEntityType customEntityType = values[i];
                try {
                    ((Map)getPrivateStatic(EntityTypes.class, "d")).remove(customEntityType.getCustomClass());
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                }
                try {
                    ((Map)getPrivateStatic(EntityTypes.class, "f")).remove(customEntityType.getCustomClass());
                }
                catch (Exception ex2) {
                    ex2.printStackTrace();
                }
            }
            CustomEntityType[] values2;
            for (int length2 = (values2 = values()).length, j = 0; j < length2; ++j) {
                final CustomEntityType customEntityType2 = values2[j];
                try {
                    a(customEntityType2.getNMSClass(), customEntityType2.getName(), customEntityType2.getID());
                }
                catch (Exception ex3) {
                    ex3.printStackTrace();
                }
            }
            BiomeBase[] array;
            try {
                array = (BiomeBase[])getPrivateStatic(BiomeBase.class, "biomes");
            }
            catch (Exception ex5) {
                return;
            }
            BiomeBase[] array2;
            for (int length3 = (array2 = array).length, k = 0; k < length3; ++k) {
                final BiomeBase biomeBase = array2[k];
                if (biomeBase == null) {
                    break;
                }
                String[] array3;
                for (int length4 = (array3 = new String[] { "as", "at", "au", "av" }).length, l = 0; l < length4; ++l) {
                    final String s = array3[l];
                    try {
                        final Field declaredField = BiomeBase.class.getDeclaredField(s);
                        declaredField.setAccessible(true);
                        for (final BiomeBase.BiomeMeta biomeMeta : (List)declaredField.get(biomeBase)) {
                            CustomEntityType[] values3;
                            for (int length5 = (values3 = values()).length, n = 0; n < length5; ++n) {
                                final CustomEntityType customEntityType3 = values3[n];
                                if (customEntityType3.getCustomClass().equals(biomeMeta.b)) {
                                    biomeMeta.b = customEntityType3.getNMSClass();
                                }
                            }
                        }
                    }
                    catch (Exception ex4) {
                        ex4.printStackTrace();
                    }
                }
            }
        }
        
        public static Entity spawnX(final Location location, final EnumColor color, final Float n) {
            final WorldServer handle = ((CraftWorld)location.getWorld()).getHandle();
            final CustomSheep183 customSheep183 = new CustomSheep183((World)handle);
            customSheep183.setPosition(location.getX(), location.getY(), location.getZ());
            customSheep183.setColor(color);
            customSheep183.yaw = n;
            ((World)handle).addEntity((net.minecraft.server.v1_8_R2.Entity)customSheep183);
            return (Entity)customSheep183.getBukkitEntity();
        }
        
        private static Object getPrivateStatic(final Class<?> clazz, final String s) {
            final Field declaredField = clazz.getDeclaredField(s);
            declaredField.setAccessible(true);
            return declaredField.get(null);
        }
        
        private static void a(final Class<?> clazz, final String s, final int n) {
            try {
                ((Map)getPrivateStatic(EntityTypes.class, "d")).put(clazz, s);
                ((Map)getPrivateStatic(EntityTypes.class, "f")).put(clazz, n);
            }
            catch (Exception ex) {}
        }
    }
}
