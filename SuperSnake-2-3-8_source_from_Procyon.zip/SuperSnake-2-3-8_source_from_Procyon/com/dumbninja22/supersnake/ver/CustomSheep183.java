// 
// Decompiled by Procyon v0.5.30
// 

package com.dumbninja22.supersnake.ver;

import java.lang.reflect.Field;
import org.bukkit.craftbukkit.v1_8_R2.util.UnsafeList;
import net.minecraft.server.v1_8_R2.PathfinderGoalSelector;
import net.minecraft.server.v1_8_R2.World;
import net.minecraft.server.v1_8_R2.EntitySheep;

public class CustomSheep183 extends EntitySheep
{
    public CustomSheep183(final World world) {
        super(world);
        try {
            final Field declaredField = PathfinderGoalSelector.class.getDeclaredField("b");
            declaredField.setAccessible(true);
            final Field declaredField2 = PathfinderGoalSelector.class.getDeclaredField("c");
            declaredField2.setAccessible(true);
            declaredField.set(this.goalSelector, new UnsafeList());
            declaredField.set(this.targetSelector, new UnsafeList());
            declaredField2.set(this.goalSelector, new UnsafeList());
            declaredField2.set(this.targetSelector, new UnsafeList());
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
