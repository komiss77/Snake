// 
// Decompiled by Procyon v0.5.30
// 

package com.dumbninja22.supersnake.ver;

import java.lang.reflect.Field;
import com.google.common.collect.Sets;
import net.minecraft.server.v1_9_R2.PathfinderGoalSelector;
import net.minecraft.server.v1_9_R2.World;
import net.minecraft.server.v1_9_R2.EntitySheep;

public class CustomSheep194 extends EntitySheep
{
    public CustomSheep194(final World world) {
        super(world);
        try {
            final Field declaredField = PathfinderGoalSelector.class.getDeclaredField("b");
            declaredField.setAccessible(true);
            final Field declaredField2 = PathfinderGoalSelector.class.getDeclaredField("c");
            declaredField2.setAccessible(true);
            declaredField.set(this.goalSelector, Sets.newLinkedHashSet());
            declaredField.set(this.targetSelector, Sets.newLinkedHashSet());
            declaredField2.set(this.goalSelector, Sets.newLinkedHashSet());
            declaredField2.set(this.targetSelector, Sets.newLinkedHashSet());
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
