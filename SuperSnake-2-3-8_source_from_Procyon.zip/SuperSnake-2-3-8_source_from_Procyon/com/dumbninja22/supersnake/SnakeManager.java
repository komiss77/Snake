// 
// Decompiled by Procyon v0.5.30
// 

package com.dumbninja22.supersnake;

import org.bukkit.Effect;
import java.util.Iterator;
import org.bukkit.util.Vector;
import org.bukkit.Location;
import java.util.Map;
import org.bukkit.entity.EntityType;
import com.dumbninja22.supersnake.ninjagamesAPI.GameState;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.event.EventPriority;
import org.bukkit.inventory.ItemStack;
import com.dumbninja22.supersnake.ninjagamesAPI.FileManager;
import org.bukkit.Material;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.Bukkit;
import java.util.ArrayList;
import org.bukkit.scheduler.BukkitTask;
import java.util.List;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;

public class SnakeManager implements Listener
{
    Player p;
    int color;
    private int kills;
    Entity lastSnake;
    List<Entity> allSheep;
    int speedBoost;
    private boolean winner;
    boolean sugarBoosted;
    Entity masterSheep;
    List<Entity> invincibleFollowers;
    Minigame mg;
    BukkitTask masterTask;
    BukkitTask collisionKicker;
    
    public SnakeManager(final Player player, final int color, final Minigame mg) {
        this.color = 0;
        this.kills = 0;
        this.allSheep = new ArrayList<Entity>();
        this.speedBoost = 0;
        this.winner = false;
        this.sugarBoosted = false;
        this.invincibleFollowers = new ArrayList<Entity>();
        this.p = player;
        this.mg = mg;
        this.color = color;
        final Entity spawnX = Main.nmsAccess.spawnX(player.getLocation(), this.color, player.getLocation().getYaw());
        if (spawnX == null || !spawnX.isValid()) {
            Bukkit.getLogger().info("Unable to spawn first sheep...");
            Bukkit.getLogger().info("The problem is most likely because you have animals disabled, especially if you're running Multiverse.");
        }
        else {
            (this.masterSheep = spawnX).setPassenger((Entity)player);
            this.invincibleFollowers.add(spawnX);
            this.lastSnake = (Entity)this.p;
            this.go();
            this.startCollisionKicker();
        }
        Bukkit.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)Main.getPlugin((Class)Main.class));
    }
    
    @EventHandler
    public void dontGetOff(final PlayerMoveEvent playerMoveEvent) {
        if (this.p != null && this.masterSheep != null && this.masterSheep.getPassenger() == null) {
            this.masterSheep.setPassenger((Entity)this.p);
        }
    }
    
    @EventHandler
    public void damm(final EntityDamageByEntityEvent entityDamageByEntityEvent) {
        if (this.p != null && this.mg != null && (this.allSheep.contains(entityDamageByEntityEvent.getEntity()) || this.masterSheep == entityDamageByEntityEvent.getEntity())) {
            entityDamageByEntityEvent.setCancelled(true);
        }
    }
    
    protected void addToKills() {
        ++this.kills;
    }
    
    protected int getKills() {
        return this.kills;
    }
    
    public boolean isWinner() {
        return this.winner;
    }
    
    @EventHandler(priority = EventPriority.MONITOR)
    public void speedBoostManager(final PlayerInteractEvent playerInteractEvent) {
        final Player player = playerInteractEvent.getPlayer();
        if (this.mg != null && this.p != null && this.p.getUniqueId() == player.getUniqueId() && (playerInteractEvent.getAction() == Action.RIGHT_CLICK_AIR || playerInteractEvent.getAction() == Action.RIGHT_CLICK_BLOCK) && this.p.getItemInHand().getType() == Material.FEATHER) {
            this.speedBoost = FileManager.speedboostTimeTicks;
            if (this.p.getItemInHand().getAmount() == 1) {
                this.p.setItemInHand(new ItemStack(Material.AIR));
            }
            else {
                this.p.getItemInHand().setAmount(this.p.getItemInHand().getAmount() - 1);
            }
        }
    }
    
    @EventHandler
    public void sugarPickupEventSpeed(final PlayerPickupItemEvent playerPickupItemEvent) {
        if (this.p == null || this.mg == null) {
            return;
        }
        if (this.p.getUniqueId() == playerPickupItemEvent.getPlayer().getUniqueId() && playerPickupItemEvent.getItem().getItemStack().getType() == Material.SUGAR) {
            this.mg.sugars.remove(playerPickupItemEvent.getItem());
            playerPickupItemEvent.getItem().remove();
            playerPickupItemEvent.setCancelled(true);
            this.speedBoost = FileManager.speedboostTimeTicks;
            this.sugarBoosted = true;
        }
    }
    
    public void startCollisionKicker() {
        this.collisionKicker = new BukkitRunnable() {
            public void run() {
                if (SnakeManager.this.mg == null) {
                    this.cancel();
                    return;
                }
                if (SnakeManager.this.mg.getOfficialArena().getState() == GameState.STARTED || SnakeManager.this.mg.getOfficialArena().getState() == GameState.INGAME) {
                    final Location location = SnakeManager.this.masterSheep.getLocation();
                    location.setDirection(SnakeManager.this.p.getLocation().getDirection());
                    location.setPitch(0.0f);
                    1.0;
                    int speedBoost;
                    if (SnakeManager.this.speedBoost != 0) {
                        speedBoost = SnakeManager.this.speedBoost;
                    }
                    else {
                        speedBoost = 0;
                    }
                    Double n;
                    if (speedBoost > 0) {
                        if (SnakeManager.this.sugarBoosted) {
                            n = FileManager.snakeSugerBoostedSpeed;
                        }
                        else {
                            n = FileManager.snakeBoostedSpeed;
                        }
                        --speedBoost;
                        SnakeManager.this.speedBoost = speedBoost;
                    }
                    else {
                        n = FileManager.snakeDefaultSpeed;
                        SnakeManager.this.sugarBoosted = false;
                    }
                    final Vector multiply = location.getDirection().multiply((double)n);
                    multiply.setY(0);
                    Main.nmsAccess.changeDir(SnakeManager.this.masterSheep, SnakeManager.this.p);
                    SnakeManager.this.masterSheep.setVelocity(multiply.multiply((double)n));
                }
                for (final Entity entity : SnakeManager.this.p.getNearbyEntities(0.8, 1.0, 0.8)) {
                    if (entity.getType() == EntityType.SHEEP && SnakeManager.this.mg.hasStarted() && !SnakeManager.this.invincibleFollowers.contains(entity)) {
                        Player p = null;
                        for (final Map.Entry<Player, SnakeManager> entry : SnakeManager.this.mg.tracker.entrySet()) {
                            if (entry.getKey() != null && entry.getValue() != null && entry.getValue().allSheep.contains(entity)) {
                                p = entry.getKey();
                            }
                        }
                        if (SnakeManager.this.allSheep.contains(entity)) {
                            p = SnakeManager.this.p;
                        }
                        if (p != null) {
                            SnakeManager.this.mg.ism.updateScoreboard(SnakeManager.this.p, p);
                            SnakeManager.this.mg.hitMessage(SnakeManager.this.p, p);
                        }
                        else {
                            SnakeManager.this.mg.ism.updateScoreboard(SnakeManager.this.p, SnakeManager.this.p);
                            SnakeManager.this.mg.hitMessage(SnakeManager.this.p, null);
                        }
                        if (SnakeManager.this.mg.tracker.size() < 3) {
                            if (p != SnakeManager.this.p && p != null) {
                                SnakeManager.this.mg.tracker.get(p).setWinner();
                            }
                            else {
                                for (final SnakeManager snakeManager : SnakeManager.this.mg.tracker.values()) {
                                    if (snakeManager != SnakeManager.this.mg.tracker.get(SnakeManager.this.p)) {
                                        snakeManager.setWinner();
                                    }
                                }
                            }
                        }
                        SnakeManager.this.terminate();
                        SnakeManager.this.mg.leavePlayer(SnakeManager.this.p, false);
                        SnakeManager.this.p = null;
                        SnakeManager.this.mg = null;
                    }
                }
            }
        }.runTaskTimer((Plugin)Main.getPlugin((Class)Main.class), 0L, 1L);
    }
    
    protected void setWinner() {
        this.winner = true;
    }
    
    public void terminate() {
        if (this.masterTask != null) {
            this.masterTask.cancel();
        }
        if (this.collisionKicker != null) {
            this.collisionKicker.cancel();
        }
        for (final Entity entity : this.allSheep) {
            entity.getWorld().playEffect(entity.getLocation(), Effect.COLOURED_DUST, 0);
            entity.remove();
        }
        this.masterSheep.remove();
        this.allSheep.clear();
        this.lastSnake = null;
        this.masterSheep = null;
        this.invincibleFollowers.clear();
        this.kills = 0;
    }
    
    public void go() {
        this.masterTask = new BukkitRunnable() {
            public void run() {
                if (SnakeManager.this.mg == null) {
                    return;
                }
                if (SnakeManager.this.mg.hasStarted()) {
                    final Entity spawnX = Main.nmsAccess.spawnX(SnakeManager.this.lastSnake.getLocation(), SnakeManager.this.color, SnakeManager.this.lastSnake.getLocation().getYaw());
                    Main.nmsAccess.pathfind(SnakeManager.this.lastSnake, spawnX, SnakeManager.this.p, SnakeManager.this.mg);
                    SnakeManager.this.allSheep.add(spawnX);
                    if (SnakeManager.this.allSheep.size() < 3) {
                        SnakeManager.this.invincibleFollowers.add(spawnX);
                    }
                    SnakeManager.this.lastSnake = spawnX;
                }
            }
        }.runTaskTimer((Plugin)Main.getPlugin((Class)Main.class), 50L, 40L);
    }
}
