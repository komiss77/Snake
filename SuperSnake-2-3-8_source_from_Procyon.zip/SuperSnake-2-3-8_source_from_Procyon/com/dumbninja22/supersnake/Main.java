// 
// Decompiled by Procyon v0.5.30
// 

package com.dumbninja22.supersnake;

import java.net.URLConnection;
import java.io.IOException;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import com.dumbninja22.supersnake.ninjagamesAPI.CommandHandler;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.event.EventHandler;
import org.bukkit.ChatColor;
import com.dumbninja22.supersnake.ninjagamesAPI.Messages;
import com.dumbninja22.supersnake.ninjagamesAPI.FileManager;
import com.dumbninja22.supersnake.ninjagamesAPI.ArenaManager;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import java.lang.reflect.InvocationTargetException;
import com.dumbninja22.supersnake.ninjagamesAPI.Sequences;
import org.bukkit.plugin.Plugin;
import org.bukkit.Bukkit;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin implements Listener
{
    public static NMS nmsAccess;
    
    public void onEnable() {
        loadConfig0();
        Bukkit.getLogger().info("Super Snake has been enabled!");
        this.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)this);
        if (!this.getDataFolder().exists()) {
            this.getDataFolder().mkdir();
        }
        if (this.getConfig() == null) {
            this.saveDefaultConfig();
        }
        Sequences.startupSequence();
        final String[] split = this.getServer().getClass().getPackage().getName().split("\\.");
        final String s = split[split.length - 1];
        try {
            final Class<?> forName = Class.forName("com.dumbninja22.supersnake.ver." + s);
            if (NMS.class.isAssignableFrom(forName)) {
                Main.nmsAccess = (NMS)forName.getConstructor((Class<?>[])new Class[0]).newInstance(new Object[0]);
            }
            else {
                Bukkit.getLogger().info("Hey! Sorry about the dissapointment, but this plugin isn't working right now. Tell the author.");
                this.setEnabled(false);
            }
        }
        catch (ClassNotFoundException ex) {
            Bukkit.getLogger().info("Hey! Sorry about the dissapointment, but this plugin isn't compatible with this version of MC. Tell the author to fix it. Disabling...");
            this.setEnabled(false);
        }
        catch (InstantiationException ex2) {}
        catch (IllegalAccessException ex3) {}
        catch (IllegalArgumentException ex4) {}
        catch (InvocationTargetException ex5) {}
        catch (NoSuchMethodException ex6) {
            Bukkit.getLogger().info("Hey! Sorry about the dissapointment, but this plugin isn't compatible with this version of MC (err 2). Tell the author to fix it. Disabling...");
            this.setEnabled(false);
        }
        catch (SecurityException ex7) {}
        if (this.isEnabled()) {
            Main.nmsAccess.registerEntities();
        }
    }
    
    public void onDisable() {
        Sequences.shutdownSequence();
    }
    
    @EventHandler
    public void commandBlocker(final PlayerCommandPreprocessEvent playerCommandPreprocessEvent) {
        if (ArenaManager.getManager().searchForPlayer(playerCommandPreprocessEvent.getPlayer()) && ArenaManager.getManager().getPlayersArena(playerCommandPreprocessEvent.getPlayer()).getIArena().hasStarted() && !FileManager.allowedcmds.contains(playerCommandPreprocessEvent.getMessage())) {
            ArenaManager.getManager().removePlayer(playerCommandPreprocessEvent.getPlayer(), false);
            playerCommandPreprocessEvent.getPlayer().sendMessage(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.commandBlockerMsg));
        }
    }
    
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        if (array.length < 1) {
            commandSender.sendMessage(ChatColor.AQUA + "Please enter a command!");
            return !commandSender.isOp() && !commandSender.hasPermission("supersnake.arenacreation");
        }
        return CommandHandler.handleCommand(commandSender, command, s, array);
    }
}
