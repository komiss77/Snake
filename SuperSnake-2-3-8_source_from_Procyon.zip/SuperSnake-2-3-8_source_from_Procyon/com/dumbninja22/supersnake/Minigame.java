// 
// Decompiled by Procyon v0.5.30
// 

package com.dumbninja22.supersnake;

import com.dumbninja22.supersnake.ninjagamesAPI.ShopManager;
import org.bukkit.OfflinePlayer;
import com.dumbninja22.supersnake.ninjagamesAPI.EconomyManager;
import com.google.gson.JsonObject;
import org.bukkit.GameMode;
import com.dumbninja22.supersnake.ninjagamesAPI.GUIManager;
import org.bukkit.World;
import org.bukkit.inventory.ItemStack;
import org.bukkit.Material;
import org.bukkit.Location;
import com.dumbninja22.supersnake.ninjagamesAPI.Utils;
import java.util.Random;
import com.dumbninja22.supersnake.ninjagamesAPI.GameState;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.event.EventHandler;
import com.dumbninja22.supersnake.ninjagamesAPI.ArenaManager;
import org.bukkit.entity.Monster;
import com.dumbninja22.supersnake.ninjagamesAPI.FileManager;
import org.bukkit.event.entity.CreatureSpawnEvent;
import java.util.Iterator;
import org.bukkit.ChatColor;
import com.dumbninja22.supersnake.ninjagamesAPI.Messages;
import java.util.Map;
import org.bukkit.plugin.Plugin;
import org.bukkit.Bukkit;
import java.util.ArrayList;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.entity.Item;
import java.util.List;
import com.dumbninja22.supersnake.ninjagamesAPI.Arena;
import com.dumbninja22.supersnake.ninjagamesAPI.IScoreboardManager;
import org.bukkit.entity.Player;
import java.util.HashMap;
import org.bukkit.event.Listener;

public class Minigame implements Listener
{
    public final HashMap<Player, Integer> hashmapAlpha;
    public IScoreboardManager ism;
    Minigame a;
    private Arena officialArena;
    public List<Item> sugars;
    public final HashMap<Player, SnakeManager> tracker;
    BukkitTask sugar;
    
    public Minigame(final Arena officialArena) {
        this.hashmapAlpha = new HashMap<Player, Integer>();
        this.ism = null;
        this.a = this;
        this.sugars = new ArrayList<Item>();
        this.tracker = new HashMap<Player, SnakeManager>();
        this.officialArena = officialArena;
        Bukkit.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)Main.getPlugin((Class)Main.class));
    }
    
    public void hitMessage(final Player player, Player player2) {
        try {
            if (player == null) {
                return;
            }
            if (player2 == null) {
                player2 = player;
            }
            if (player2 != player) {
                this.tracker.get(player2).addToKills();
            }
            final Iterator<Map.Entry<Player, Integer>> iterator = this.hashmapAlpha.entrySet().iterator();
            while (iterator.hasNext()) {
                iterator.next().getKey().sendMessage(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.snakeHitMessage).replace("[X]", player.getDisplayName()).replace("[Y]", player2.getDisplayName()).replace("[Z]", new StringBuilder(String.valueOf(this.hashmapAlpha.size() - 1)).toString()));
            }
        }
        catch (Exception ex) {}
    }
    
    public void setOfficialArena(final Arena officialArena) {
        this.officialArena = officialArena;
    }
    
    @EventHandler
    public void onHostileSpawn(final CreatureSpawnEvent creatureSpawnEvent) {
        if (!FileManager.allowHostileMobSpawningInArena && creatureSpawnEvent.getEntity() instanceof Monster && this.officialArena != null && this.officialArena.getBoundsLow() != null && this.officialArena.getBoundsHigh() != null && ArenaManager.isInside(creatureSpawnEvent.getEntity().getLocation(), this.officialArena.getBoundsLow().toVector(), this.officialArena.getBoundsHigh().toVector())) {
            creatureSpawnEvent.setCancelled(true);
        }
    }
    
    public Arena getOfficialArena() {
        return this.officialArena;
    }
    
    public boolean playerHasSpeedBoost(final Player player) {
        return ArenaManager.getManager().searchForPlayer(player) && this.tracker.containsKey(player) && this.tracker.get(player).speedBoost != 0;
    }
    
    public boolean wasPlayerSugarBoosted(final Player player) {
        return ArenaManager.getManager().searchForPlayer(player) && this.tracker.containsKey(player) && this.tracker.get(player).sugarBoosted;
    }
    
    public void sugarManager() {
        this.sugar = new BukkitRunnable() {
            public void run() {
                if (Minigame.this.officialArena.getState() == GameState.WAITING || Minigame.this.officialArena.getState() == GameState.STARTING) {
                    this.cancel();
                    return;
                }
                if (new Random().nextInt(FileManager.chanceOfSugerSpawning) == 0 && Minigame.this.sugars.size() < FileManager.maxSugarOnGround) {
                    int n;
                    if (Minigame.this.officialArena.getBoundsLow().getBlockX() > Minigame.this.officialArena.getBoundsHigh().getBlockX()) {
                        n = Utils.randInt(Minigame.this.officialArena.getBoundsHigh().getBlockX(), Minigame.this.officialArena.getBoundsLow().getBlockX());
                    }
                    else {
                        n = Utils.randInt(Minigame.this.officialArena.getBoundsLow().getBlockX(), Minigame.this.officialArena.getBoundsHigh().getBlockX());
                    }
                    final int n2 = Minigame.this.officialArena.getSpawns().get(0).getBlockY() + 1;
                    int n3;
                    if (Minigame.this.officialArena.getBoundsLow().getBlockZ() > Minigame.this.officialArena.getBoundsHigh().getBlockZ()) {
                        n3 = Utils.randInt(Minigame.this.officialArena.getBoundsHigh().getBlockZ(), Minigame.this.officialArena.getBoundsLow().getBlockZ());
                    }
                    else {
                        n3 = Utils.randInt(Minigame.this.officialArena.getBoundsLow().getBlockZ(), Minigame.this.officialArena.getBoundsHigh().getBlockZ());
                    }
                    final World world = Minigame.this.officialArena.getSpawns().get(0).getWorld();
                    Minigame.this.sugars.add(world.dropItemNaturally(new Location(world, (double)n, (double)n2, (double)n3), new ItemStack(Material.SUGAR, 1)));
                }
            }
        }.runTaskTimer((Plugin)Main.getPlugin((Class)Main.class), 0L, 20L);
    }
    
    public void replaceHashMapAlpha(final Player player, final Integer n) {
        this.hashmapAlpha.put(player, n);
    }
    
    public void joinPlayerLobby(final Player player, final Plugin plugin) {
        GUIManager.givePlayerNametag(player);
        final Random random = new Random();
        0;
        this.hashmapAlpha.put(player, random.nextInt(15));
        player.setGameMode(GameMode.ADVENTURE);
        if (this.ism == null) {
            this.ism = new IScoreboardManager(this);
        }
        else {
            this.ism.addPlayer(player);
        }
    }
    
    public void leavePlayer(final Player player, final boolean b) {
        if (this.tracker.containsKey(player)) {
            boolean b2 = false;
            if (this.tracker.get(player).isWinner()) {
                final JsonObject jsonObject = new JsonObject();
                jsonObject.addProperty("text", Messages.titleMessageWin);
                jsonObject.addProperty("color", "aqua");
                Main.nmsAccess.showTitle(jsonObject.toString(), player);
                b2 = true;
            }
            if (EconomyManager.economy != null) {
                EconomyManager.economy.depositPlayer((OfflinePlayer)player, (double)FileManager.creditForParticipation);
                player.sendMessage(Utils.tran(Messages.creditForParticipation.replace("[X]", new StringBuilder(String.valueOf(FileManager.creditForParticipation)).toString())));
                if (b2) {
                    EconomyManager.economy.depositPlayer((OfflinePlayer)player, (double)FileManager.creditOnWin);
                    player.sendMessage(Utils.tran(Messages.creditForWin.replace("[X]", new StringBuilder(String.valueOf(FileManager.creditOnWin)).toString())));
                }
                if (this.tracker.get(player).getKills() > 0) {
                    EconomyManager.economy.depositPlayer((OfflinePlayer)player, (double)(FileManager.creditOnHitSomeoneOut * this.tracker.get(player).getKills()));
                    player.sendMessage(Utils.tran(Messages.creditForHitSomeoneOut.replace("[X]", new StringBuilder().append(FileManager.creditOnHitSomeoneOut * this.tracker.get(player).getKills()).toString()).replace("[Y]", new StringBuilder(String.valueOf(this.tracker.get(player).getKills())).toString())));
                }
            }
            this.hashmapAlpha.remove(player);
            if (this.tracker.get(player).masterSheep != null) {
                this.tracker.get(player).terminate();
            }
            this.tracker.remove(player);
            if (!b) {
                if (this.hashmapAlpha.size() < 2) {
                    ArenaManager.getManager().stopArena(this.officialArena.getId(), player);
                }
                else {
                    ArenaManager.getManager().removePlayer(player, true);
                }
            }
        }
    }
    
    public void stop() {
        try {
            if (this.sugar != null) {
                this.sugar.cancel();
            }
            final Iterator<Item> iterator = this.sugars.iterator();
            while (iterator.hasNext()) {
                iterator.next().remove();
            }
            this.sugars.clear();
            for (final Map.Entry<Player, SnakeManager> entry : this.tracker.entrySet()) {
                final Player player = entry.getKey();
                if (entry.getValue().mg != null) {
                    entry.getValue().terminate();
                }
                this.ism.removePlayer(player);
            }
            this.hashmapAlpha.clear();
            this.ism = null;
            this.tracker.clear();
        }
        catch (NullPointerException ex) {
            Utils.echo("Something went wrong when ending the game.");
        }
    }
    
    public void start(final boolean b) {
        final Iterator<Map.Entry<Player, Integer>> iterator = this.hashmapAlpha.entrySet().iterator();
        while (iterator.hasNext()) {
            final Player player = iterator.next().getKey();
            if (player != null) {
                player.setFoodLevel(20);
                if (ShopManager.selected.containsKey(player.getUniqueId())) {
                    if (ShopManager.selected.get(player.getUniqueId()).contains("fastsnake")) {
                        player.getInventory().setItem(0, new ItemStack(Material.FEATHER, FileManager.fastKitBoosts));
                    }
                    if (ShopManager.selected.get(player.getUniqueId()).contains("ferrarisnake")) {
                        player.getInventory().setItem(0, new ItemStack(Material.FEATHER, FileManager.ferrariKitBoosts));
                    }
                }
                this.tracker.put(player, new SnakeManager(player, this.hashmapAlpha.get(player), this));
            }
        }
    }
    
    public void started() {
        this.sugarManager();
    }
    
    public boolean hasStarted() {
        return this.getOfficialArena().getState() == GameState.STARTED || this.getOfficialArena().getState() == GameState.INGAME;
    }
    
    public boolean getIfStartedTeleport() {
        return this.tracker.size() > 0 && this.officialArena.getPlayers().size() > 0;
    }
}
